﻿<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Untitled Document</title>
</head>

<body>
<?php

$goodsname=$_POST["goodsname"];
$goodsnum=$_POST["goodsnum"];
$goodsprice=$_POST["goodsprice"];
$goodsdate=$_POST["goodsdate"];
$supplierid=$_POST["supplierid"];


require('DB_Info.php');

if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

$sql = "SELECT * FROM goods where goodsid='$goodsid'";
$result = mysqli_query($conn, $sql);

if (mysqli_num_rows($result) > 0) {
	 echo "<script>{alert('商品名称相同');location.href='supplier_Info.php'}</script>";
}else{
	$sql="INSERT INTO goods (goodsname,goodsnum,goodsprice,goodsdate,supplierid) VALUES ('$goodsname','$goodsnum','$goodsprice','$goodsdate','$supplierid')";
	if (mysqli_query($conn, $sql)) {
 	   echo "<script>{alert('商品成功增建了');window.location.href='supplier_Info.php?supplierid=$supplierid'  }</script>";
	} else {
		echo "<script>{alert('商品信息未能增建');location.href='supplier_Info.php?supplierid=$supplierid'}</script>";
	}
}

?>
</body>
</html>