﻿<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Untitled Document</title>
<link rel="stylesheet" type="text/css" href="CSS/css_style.css"/>
<style>
*{
	font-size:18px;
}

select{
    width:250px;

	border-bottom:#CCC 1px solid;
}
input[type=text] {
    width:250px;
    box-sizing: border-box;
    border: 2px solid #ccc;
    border-radius: 4px;
    background-color: white;
    background-position: 10px 10px; 
    background-repeat: no-repeat;
}
table{border-radius: 20px;
	border:#999 solid 3px;
	padding:50px 50px 50px 50px;
	margin-top:50px;
}
</style>
</head>

<body>
<?php

require('DB_Info.php');

if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

$sql = "SELECT * FROM department";
$result = mysqli_query($conn, $sql);
$department_box="";

if (mysqli_num_rows($result) > 0) {
    while($row = mysqli_fetch_assoc($result)) {
        $department_box.="<option value=".$row["dpid"].">". $row["dpname"] . "</option>";
    }
	$department_box.="</select>";
} else {
    echo "DP Error";
}

$Company_box="<option value='ASIA'>ASIA</option><option value='HONG KONG'>HONG KONG</option></select>";

echo"<form action=S_Create.php method=POST><center><table style='text-align:left;'>
	<tr><th><span style='text-align:left;'>*员工号</span></th><td><input type=text name=sno></td></tr>
        <tr><th><span style='text-align:left;'>*First Name</span></th><td><input type=text style=text-transform:capitalize name=fname></td></tr>
        <tr><th><span style='text-align:left;'>*Last Name</span></th><td><input type=text style=text-transform:capitalize name=lname></td></tr>
	<tr><th><span style='text-align:left;'>*中文名</span></th><td><input type=text style=text-transform:capitalize name=sname></td></tr>
	<tr><th><span style='text-align:left;'>*所属公司</span></th><td><select name=company id='table_size_1'><option></option>".$Company_box."</td></tr>
	<tr><th><span style='text-align:left;'>部门</span></th><td><select name=dpid id='table_size_1'><option></option>".$department_box."</td></tr>
	<tr><th><span style='text-align:left;'>职位</span></th><td><input type=text style=text-transform:capitalize name=position></td></tr>
	<tr><th><span style='text-align:left;'>公司电话</span></th><td><input type=text name=ctel></td></tr>
	<tr><th><span style='text-align:left;'>手提电话</span></th><td><input type=text name=ptel></td></tr>
	<tr><th><span style='text-align:left;'>E-mail</span></th><td><input type=text name=email></td></tr>	
	<tr><td></td></tr>
	<tr><td></td></tr>
	<tr><td></td></tr>
	<tr><td></td></tr>
	<tr><td></td></tr>
	<tr><td></td></tr>
	<tr><td></td></tr>
	<tr><td></td></tr>
	<tr><td></td></tr>
<tr><th></th><th>&nbsp;&nbsp;&nbsp;<span style='text-align:left;'><input type=submit name=submit value=创建></span><input type=submit name=Submit onclick=javascript:history.back(-1); value=返回></th></tr>
</table></center></form>";
?>
</body>
</html>