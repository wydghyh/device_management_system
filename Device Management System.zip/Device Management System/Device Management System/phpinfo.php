
<?php
 echo phpinfo();
?>
