﻿<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<link rel="stylesheet" href="main.css">
<title>Untitled Document</title>
</head>

<body>
<?php
session_start();

$supplierid = $_POST['supplierid'];


$goodsid = $_POST['goodsid'];
$goodsname = $_POST['goodsname'];
$goodsnum = $_POST['goodsnum'];
$goodsdate = $_POST['goodsdate'];
$goodsprice= $_POST['goodsprice'];


require('DB_Info.php');

if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

$sql="UPDATE goods SET goodsname ='$goodsname',goodsnum ='$goodsnum',goodsdate='$goodsdate',goodsprice ='$goodsprice' WHERE goodsid ='$goodsid'";

if (mysqli_query($conn, $sql)) {
    echo "<script>{alert('该公司购买的商品资料己更新了');location.href='supplier_Info.php?supplierid=$supplierid'}</script>";
} else {
	echo "<script>{alert('更新错误');location.href='supplier_Info.php?supplierid=$supplierid'}</script>";
}
?>

</body>
</html>