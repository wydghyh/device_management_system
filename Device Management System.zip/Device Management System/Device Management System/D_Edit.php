﻿<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Untitled Document</title>
<style>
table{border-radius: 20px;
	border:#999 solid 3px;
	padding:50px 50px 50px 50px;
	margin-top:25px;
}
</style>
<link rel="stylesheet" type="text/css" href="CSS/css_style.css"/>
</head>
<body>
<?php

require('DB_Info.php');

if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

$sql = "SELECT * FROM catalog";
$result = mysqli_query($conn, $sql);
$Catalog_box="";

if (mysqli_num_rows($result) > 0) {
    while($row = mysqli_fetch_assoc($result)) {
        $Catalog_box.="<option value=".$row["cid"].">". $row["cname"] . "</option>";
    }
	$Catalog_box.="</select>";
} else {
    echo "錯誤";
}

$Company_box="<option value='ASIA'>ASIA</option><option value='HONG KONG'>HONG KONG</option></select>";
$did=$_POST['did'];




$sql = "SELECT * FROM device inner join catalog WHERE device.cid=catalog.cid and device.did='$did'";
$result = mysqli_query($conn, $sql);
$List="<center><form action=D_Update.php method=POST><table style='text-align:left;'>";

if (mysqli_num_rows($result) > 0) {
	while($row = mysqli_fetch_assoc($result)) {
		$List.="
                <tr><th>Device no.</th><td>".$row["did"]."</td></tr>
		<tr><th>Category</th><td><select id='table_size_1' name=cid><option value='".$row["cid"]."'>". $row["cname"] . "</option>".$Catalog_box."</td></tr>
		<tr><th>Brand</th><td><input type=text id='table_size_1' name=brand style='text-transform:capitalize'value='".$row["brand"]."'></td></tr>
                <tr><th>Series</th><td><input type=text id='table_size_1' name=series style='text-transform:uppercase' value='".$row["series"]."'></td></tr>
		<tr><th>Model</th><td><input type=text id='table_size_1' name=model style='text-transform:capitalize' value='".$row["model"]."'></td></tr>
		<tr><th>Sereies Number</th><td><input type=text id='table_size_1' style='text-transform:uppercase' name=sn value='".$row["sn"]."'></td></tr>
                <tr><th>Ethernet address</th><td><input type=text id='table_size_1' style='text-transform:uppercase' name=mac value='".$row["mac"]."'></td></tr>
		<tr><th>Wlan address</th><td><input type=text id='table_size_1' style='text-transform:uppercase' name=netmac value='".$row["netmac"]."'></td></tr>
		<tr><th>RAM</th><td><input type=text id='table_size_1' style='text-transform:uppercase' name=ram value='".$row["ram"]."'></td></tr>
		<tr><th>Company</th><td><select id='table_size_1' name=company><option value='".$row["company"]."'>".$row["company"]."</option>".$Company_box."</td></tr>
		<tr><th>Location</th><td><input type=text id='table_size_1' style='text-transform:uppercase' name=location value='".$row["location"]."'></td></tr>
		<tr><th>Asset Number</th><td><input type=text id='table_size_1' name=assnum value='".$row["assnum"]."'></td></tr>
                <tr><th>Account Number</th><td><input type=text id='table_size_1' name=asiano value='".$row["asiano"]."'></td></tr>
		<tr><th>Purchasing Price</th><td><input type=text id='table_size_1' name=price value='".$row["price"]."'></td></tr>
		<tr><th>Purchasing date</th><td><input type=text id='table_size_1' name=purtime value='".$row["purtime"]."'></td></tr>
		<tr><th>Current Value</th><td><input type=text id='table_size_1' name=curvalue value='".$row["curvalue"]."'></td></tr>
		<tr><th>Date of retirement</th><td><input type=text id='table_size_1' name=retire value='".$row["retire"]."'></td></tr>
		<tr><th>Remark</th><td><textarea type=text name=other value='".$row["other"]."' maxlength='5000' id='table_size_1' >".$row["other"]."</textarea></td></tr>
                <tr><th><span style='text-align:left;'>Whether it's checked?</span></th><td><input type=radio name=checked value=是 checked/>是 <input type=radio name=checked value=否 >否</td></tr>
		<tr><td></td></tr>
	<tr><td></td></tr>
	<tr><td></td></tr>
	<tr><td></td></tr>
	<tr><td></td></tr>
	<tr><td></td></tr>
	<tr><td></td></tr>
	<tr><td></td></tr>
	<tr><td></td></tr>
		<tr><th></th><th>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                <input type=hidden name=did value='$did'><input type=submit name=submit value=提交>
                <th><input type=submit name=Submit onclick=javascript:history.back(-1); value=返回></th>
                
		</th></tr>
		</table></center>
		";
	}
	echo $List;
} else {
    echo "系統出現故障 !!";
}
?>
</body>
</html>