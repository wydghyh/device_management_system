﻿<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<link rel="stylesheet" href="main.css">
<title>Untitled Document</title>
</head>

<body>
<?php
$did = $_POST['did'];
$combobox = $_POST['combobox'];

require('DB_Info.php');

if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

$sql="SELECT * FROM record WHERE did='$did' AND rtime is null";
$result = mysqli_query($conn, $sql);

if (mysqli_num_rows($result) > 0) {
	while($row = mysqli_fetch_assoc($result)) {
		$rid=$row["rid"];
	}
	$rtime = $_POST['rtime'];
	
	$sql="UPDATE record SET rtime = '$rtime' WHERE rid='$rid'";
	mysqli_query($conn, $sql);
}
/*-----------------------------------------^歸還設備^-----------------------------------------*/
if($combobox=="使用中"){
	$sid = $_POST['sid'];
	$ltime = $_POST['ltime'];
	
	$sql="INSERT INTO record (did,sid,ltime) VALUES ('$did','$sid','$ltime')";
	
	if (mysqli_query($conn, $sql)) {
	    echo "<script>{alert('狀態己更新了');location.href='D_Info.php?did=$did';}</script>";
	} else {
		echo "<script>{alert('1更新錯誤');location.href='D_Page.php'}</script>";
	}
}

$sql="UPDATE device SET dstate='$combobox' WHERE did='$did'";
if (mysqli_query($conn, $sql)) {
    echo "<script>{alert('狀態己更新了');location.href='D_Info.php?did=$did';}</script>";


} else {
	echo "<script>{alert('2更新錯誤');location.href='D_Page.php'}</script>";
}

?>

</body>
</html>