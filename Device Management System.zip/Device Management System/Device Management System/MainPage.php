﻿<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>DMS</title>
<link rel="stylesheet" type="text/css" href="CSS/css_style.css"/>

<style type="text/css"> 
#header
{ 
background:url(Image/header.jpg);
background-size:cover; 
}

#body
{ 
background:url(Image/body.jpg);
background-size:cover; 
}

#rTop
{width:40px; height:40px;
align:center;
text-align:center; font-size:small;
line-height:25px; border:1px solid #999;
position:fixed; left:20px; bottom:60px;
border-color:none;
background-color:#4682B4;
cursor:pointer;}

#rTop:hover{
	background-color:#336699;

</style> 

<script>
<!--拖动滚动条或滚动鼠标轮-->
window.onscroll=function(){
if(document.body.scrollTop||document.documentElement.scrollTop>0){
document.getElementById('rTop').style.display="block"
}else{
document.getElementById('rTop').style.display="none"
}
}
<!--点击“回到顶部”按钮-->
function toTop(){
window.scrollTo('0','0');
document.getElementById('rTop').style.display="none"
}
</script>

</head>

<body>

<?PHP
session_start();
$user=$_SESSION["username"];
$role=$_SESSION["role"];
if($role=="" || $user==""){
	echo "<script>{alert('請先登入..');location.href='Index.php'}</script>";
}
?>

<div id="main">

<div id="header">
<!头部>
   
    <div id="logo"><a href="HomePage.php" target="C_Frame"><img src="Image/logo2.png" width="90%"></a></div>
    <div id="menu">

<!头部菜单>
   <center>
   <?php
		if($role=="管理員" or $role=="一般用戶" ){
        	echo"<a href=D_Page.php target=C_Frame><button class=btn_menu><image src='Image/icon2.png' width='70%'/><h3><font style='color:white;'>设备</font></h3></button></a>";
		}
	?>
    <a href="S_Page.php" target="C_Frame"><button class="btn_menu"><img src="Image/icon1.png" width="70%" title="员工" /><h3><font style="color:white;">员工</font></h3></button></a>
<a href="Supplier_Page.php" target="C_Frame"><button class="btn_menu"><img src="Image/icon4.png" width="70%" title="供应商" /><h3><font style="color:white;">供应商</font></h3></button></a>
    <?php
		if($role=="管理員"){
        	echo"<a href=Setting.php target=C_Frame><button class=btn_menu><image src='Image/icon3.png' width='70%'/><h3><font style='color:white;'>设置</font></h3></button></a>";
		}
	?>
   </center>
   </div>
	<div id="logout">        
		<?PHP
			echo $role." : ".$user."<a href=Index.php style='text-decoration:none;'><span>[登出]</span></a>";
			if($role!="管理員"){
				echo"<a href=U_Info.php style='text-decoration:none;'><span>[修改密碼]</span></a>";
			}
		?>
	</div>


</div>

<div id="frame" height="800px" >
    <?php
		if($role=="管理員" or $role=="一般用戶" ){
        	echo"<span><a href=D_Page.php target=C_Frame><image src='Image/leftico01.png'  title='设备'/><font style='color:black; font-size:19px'><b>&nbsp设备管理</b></font></a></span>";
		}
	?>                                      
    <span><a href="S_Page.php" target="C_Frame"><img src="Image/leftico02.png" title="员工" /><font style="color:black; font-size:19px"><b>&nbsp员工管理</b></font></a></span>
  <span><a href="Supplier_Page.php" target="C_Frame"><img src="Image/leftico02.png" title="供应商" /><font style="color:black; font-size:19px"><b>&nbsp供应商管理</b></font></a></span>
    <?php
		if($role=="管理員"){
        	echo"<span><a href=Setting.php target=C_Frame><image src='Image/leftico03.png'/><font style='color:black; font-size:19px'><b>&nbsp设置管理</b></font></a></span>";
		}
	?>

</div>

<div id="rTop" onClick="toTop()"><img src="Image/top.png" width="60%" style="padding-top:20%;"></div>
<div id="body">
<!主体部分>
	<iframe width="100%" height=850px" src="HomePage.php"  name="C_Frame" style="border:none";"></iframe>
</div>


</div>




</body>
</html>