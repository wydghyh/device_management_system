﻿<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>D_Info</title>
<link rel="stylesheet" type="text/css" href="CSS/css_style.css"/>
<style>

tr:nth-child(even){
	background-color: #F0F8FF;
}

th{
	text-align:left;
}
table{
	width:90%;
}

</style>
</head>
<body>
<div id="Add">

<?php



session_cache_limiter('private, must-revalidate');
session_start();


$supplierid = $_POST['supplierid'];
if ($supplierid=='') {
  $supplierid = $_GET['supplierid'];
}


require('DB_Info.php');


// Check connection
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}




echo"<form action=goods_Create.php method=POST><center><table style='text-align:left;'><tr><th></th><th>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;新建商品</th></tr>
<tr><th></th></tr>
<tr><th></th></tr>
<tr><th></th></tr>
<tr><th></th></tr>
        
        <tr><th><span style='text-align:left;'>*商品名称</span></th><td><input type=text name=goodsname id='table_size_1'></td></tr>
	<tr><th><span style='text-align:left;'>*数量</span></th><td><input type=text name=goodsnum id='table_size_1'></td></tr>
        <tr><th><span style='text-align:left;'>*商品价格</span></th><td><input type=text name=goodsprice id='table_size_1'></td></tr>
	<tr><th><span style='text-align:left;'>*购买日期</span></th><td><input type=text name=goodsdate id='table_size_1'></td></tr>
        <tr><th><span style='text-align:left;'><td><input type=hidden name=supplierid value='$supplierid'  id='table_size_1'></td></tr>
	
	
	
<tr><tr></tr>
<tr></tr>
<tr></tr>
<tr></tr>
<th></th><th>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<span style='text-align:left;'><input type=submit name=submit value=创建></span><input type=submit name=Submit onclick=javascript:history.back(-1); value=返回></th>
<th></th></tr></table></center>

</from>";


	
?>
</div>
<?php
$supplierid = $_POST['supplierid'];



$sql = "SELECT * FROM supplier where supplierid='$supplierid'";
$result = mysqli_query($conn, $sql);
$List="";

if (mysqli_num_rows($result) > 0) {
    // output data of each row
    while($row = mysqli_fetch_assoc($result)) {
		//Click On List
		
		
        $List.="
				
         
                <table style='text-align:left;border:1;color:#000080;table-layout:fixed'>

               
               <tr> <th style='width:70px;'>编号 : </th><th style='color:".$color.";width:170px;'>".$row["supplierid"]."</th></tr>
		<tr><th style='width:70px;'>名称 : </th><th style='color:".$color.";width:170px;'>".$row["suppliername"]."</th></tr>
               <tr> <th style='width:70px;'>类型 : </th><th style='color:".$color.";width:170px;'>".$row["suppliertype"]."</th></tr>
                <tr><th style='width:70px;'>负责人 : </th><th style='color:".$color.";width:170px;'>".$row["supplierperson"]."</th></tr>
		<tr><th style='width:70px;'>电话: </th><th style='color:".$color.";width:170px;'>".$row["suppliertel"]."</th></tr>
                <tr><th style='width:70px;'>Email: </th><th style='color:".$color.";width:170px;'>".$row["supplieremail"]."</th></tr>
		<tr><th style='width:75px;'>公司介绍 :  </th><th style='color:".$color.";width:170px;height:50px;overflow:hidden;text-overflow:ellipsis;word-break:keep-all'>".$row["supplierinfo"]."</th></tr>
		</table></center>"; 
		

$List.="</table></center><p>";
		echo"<br>";
		echo"<br>";
if($role=="管理員"){
		$List.="<center><table id='table_size_1'>
		<th><form action=Supplier_Edit.php method=POST><input type=hidden name=supplierid value=".$row["supplierid"]."><input type=submit name=Delete value='' style='display:none;'></form></th>
		<th><form action=Supplier_Edit.php method=POST><input type=hidden name=supplierid value=".$row["supplierid"]."><input type=submit name=Delete value=修改></form></th>
		<th><form action=Supplier_Delete.php method=POST><input type=hidden name=supplierid value=".$row["supplierid"]."><input type=submit name=Delete value=删除></form></th>
                <th><input type=submit name=Submit onclick=javascript:history.back(-1); value=返回></th>
		</tr></table></center>"; }




  }
	
} else {
     echo "目前尚未有任何供应商信息！";
}

echo $List;
?>





<div id="goods">
<?php




$sql="select * from goods inner join supplier where goods.supplierid=supplier.supplierid and goods.supplierid='$supplierid'";
$result= mysqli_query($conn,$sql);


$List="<center><table style='text-align:left;color:#585858;'><tr><th>商品名称</th><th>数量</th><th>购买价格</th><th>购买日期</th><th>供应商名称</th></tr>";

if (mysqli_num_rows($result) > 0) {
    // output data of each row
    while($row = mysqli_fetch_assoc($result)) {
        $List.="<tr><td><span style='color:".black.";font-weight:".bold.";'>".$row["goodsname"]."</span></td><td><span style='color:".black.";font-weight:".bold.";'>".$row["goodsname"]."</span></td><td><span style='color:".black.";font-weight:".bold.";'>".$row["goodsnum"]."</span></td><td><span style='color:".black.";font-weight:".bold.";'>".$row["goodsdate"]."</span></td><td><span style='color:".black.";font-weight:".bold.";'>".$row["suppliername"]."</span></td></tr>";
    }
	
	$List.="</table></center>";
	echo $List;
	
} else {
    echo "未在该公司购买商品";
}

mysqli_close($conn);
?>
</div>

<!------------------------------------------^Record^------------------------------------------>

</body>
</html>