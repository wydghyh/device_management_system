﻿<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Device List</title>
<link rel="stylesheet" type="text/css" href="CSS/css_style.css"/>
<style type="text/css">

#one{width:350px;
height:250px;
margin:50px;

float:left;
border:2px solid #999;
	 padding:20px;
	border-radius:10px;
	position:relative;
	left:45px}

#one:hover{
	transition:1.0s;
	background-color:#B0C4DE;
}
#one input[type=submit]{
position:absolute;
	width:100%;
	top:0;
	left:0;
	height:270px;
	background-color: transparent;
	border:none;
} 
table{table-layout:fixed;
width:100%;
}
#set_btn{
	left:10px;
	position:absolute;
	top:10px;
}

</style>
</head>
<body>

<a href="Supplier_add.php"><button id='set_btn'><b>增加常用供应商信息</b></button></a>
<?php

require('DB_Info.php');
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

$sql = "SELECT * FROM supplier";
$result = mysqli_query($conn, $sql);
$List="";

if (mysqli_num_rows($result) > 0) {
    // output data of each row
    while($row = mysqli_fetch_assoc($result)) {
		//Click On List
		
		
        $List.="
		<div id='one'>
		<form action='supplier_Info.php' method='post'&'get' target=C_Frame>
		<input type='submit' value=''>
		<input type='hidden' name='supplierid' value='".$row["supplierid"]."'>
		</form>
                
         


                <table style='text-align:left;border:1;color:#000000;table-layout:fixed;'>

               
               <tr> <th style='width:70px;'>编号 : </th><th style='color:".$color.";width:170px;'>".$row["supplierid"]."</th></tr>
		<tr><th style='width:70px;'>名称 : </th><th style='color:".$color.";width:170px;'>".$row["suppliername"]."</th></tr>
               <tr> <th style='width:70px;'>主营 : </th><th style='color:".$color.";width:170px;'>".$row["suppliertype"]."</th></tr>
                 <tr><th style='width:70px;'>地址: </th><th style='color:".$color.";width:170px;'>".$row["supplieraddress"]."</th></tr>
                <tr><th style='width:70px;'>负责人 : </th><th style='color:".$color.";width:170px;'>".$row["supplierperson"]."</th></tr>
		<tr><th style='width:70px;'>电话: </th><th style='color:".$color.";width:170px;'>".$row["suppliertel"]."</th></tr>
                <tr><th style='width:70px;'>Email: </th><th style='color:".$color.";width:170px;'>".$row["supplieremail"]."</th></tr>
                <tr><th style='width:70px;'>Fax: </th><th style='color:".$color.";width:170px;'>".$row["Fax"]."</th></tr>
                <tr><th style='width:70px;'>公司介绍: </th><th style='color:".$color.";width:170px;'>".$row["supplierinfo"]."</th></tr>
		
		</table>
		</div>"; 
  }
	echo $List;
} else {
     echo "目前尚未有任何供应商信息！";
}

mysqli_close($conn);
?>

</body>
</html>