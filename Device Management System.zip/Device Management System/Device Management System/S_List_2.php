﻿<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Device List</title>
<link rel="stylesheet" type="text/css" href="CSS/css_style.css"/>
</head>

<body>
<?php
$DP=$_POST["department"];
$ST=$_POST["sstate"];
$CO=$_POST["company"];
$sno=$_POST["sno"];
$sna=$_POST["fname"];
$zna=$_POST["sname"];
$Select="";

if($DP!="all"){
	$Select.=" and staff.dpid=".$DP;
}

if($CO!="all"){
		$Select.=" and staff.company='".$CO."'";
}
if($ST!="all"){
		$Select.=" and staff.sstate='".$ST."'";
}

if($sno!=""){
		$Select=" and staff.sno='".$sno."'";
}
if($sna!=""){
		$Select=" and staff.fname like '%".$sna."%'";

}
if($zna!=""){
		$Select=" and staff.sname like '%".$zna."%'";

}
require('DB_Info.php');

if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

$sql = "SELECT * FROM staff inner join department where staff.dpid=department.dpid".$Select;
$result = mysqli_query($conn, $sql);
$List="";

if (mysqli_num_rows($result) > 0) {
	
    while($row = mysqli_fetch_assoc($result)) {
		if($row["sstate"]=="在职"){
			$color="#000080";
		}else{
			$color="#808080";
		}
		
		$List.="
		<div id='li'>
		<form action='S_Info.php' method='post' target=C_Frame>
		<input type='submit' value=''>
		<input type='hidden' name='sid' value='".$row["sid"]."'>
		</form>
		
		<table style='width:100%; text-align:left;color:#808080;'>
		<tr>
		<th rowspan='2' style='width:33%;font-size:15px'>姓名 : <span style='color:".$color.";font-size:18px'>".$row["fname"]." ".$row["lname"]." ".$row["sname"]."</span></th>
		<th style='width:38%;'>员工号 : <span style='color:".$color.";'>".$row["sno"]."</span></th>
		<th style='width:30%;'>状态 : <span style='color:".$color.";'>".$row["sstate"]."</span></th>
		</tr>
		<tr>
		<th>部门 : <span>".$row["dpname"]."</span></th>
		<th>所属公司 : <span>".$row["company"]."</span></th>
		</tr>
		</table>
		</div>";
	}
	echo $List;
	
} else {
    echo "No Record";
}


mysqli_close($conn);
?>
</body>
</html>