<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Untitled Document</title>
<style>
*{
	font-size:18px;
}
input[type=submit]{
	border:none;
	border-bottom:#CCC 3px solid;
	background-color: transparent;
}
select{
    width:150px;
	border:none;
	border-bottom:#CCC 1px solid;
}
input[type=text] {
    width:150px;
    box-sizing: border-box;
    border: 2px solid #ccc;
    border-radius: 4px;
    background-color: white;
    background-position: 10px 10px; 
    background-repeat: no-repeat;
}

</style>
</head>
<body>
<?php
session_start();
$user=$_SESSION["username"];

require('DB_Info.php');

if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

$sql = "SELECT * FROM user WHERE uname='$user'";
$result = mysqli_query($conn, $sql);
$List="<center><form action='U_Update.php' method='POST'><table>";

if (mysqli_num_rows($result) > 0) {
	while($row = mysqli_fetch_assoc($result)) {
		$List.="
		<tr><th>設備編號</th><td>".$row["uname"]."</td></tr>
		<tr><th>新密碼</th><td><input type=text name=pwd></td></tr>
		<tr><th>確認新密碼</th><td><input type=text name=pwd2></td></tr>

		</table>
		<p><input type=hidden name=uid value='".$row["uid"]."'><input type=submit name=submit value=submit></from>
		</center>
		";
	}
	echo $List;
} else {
    echo "系統出現故障 !!";
}

mysqli_close($conn);
?>
</body>
</html>