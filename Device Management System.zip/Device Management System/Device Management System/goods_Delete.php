﻿

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Department_Delete</title>
</head>

<body>
<script>{confirm('Are you sure to delete?');}</script>
<?PHP

$goodsid = $_POST["goodsid"];
$supplierid=$_POST["supplierid"];


require('DB_Info.php');

$sql="DELETE FROM goods WHERE  goodsid ='$goodsid'";

if (mysqli_query($conn, $sql))

 {
    echo "<script>{alert('该公司购买记录已刪除');window.location.href='supplier_Info.php?supplierid=$supplierid'}</script>";
} else {
	echo "<script>{alert('该公司购买记录未能刪除');location.href='supplier_Info.php?supplierid=$supplierid'}</script>";
}

?>
</body>
</html>