﻿<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<link rel="stylesheet" href="main.css">
<title>Untitled Document</title>
</head>

<body>
<?php
$sid = $_POST['sid'];
$sno = $_POST['sno'];
$fname = $_POST['fname'];
$lname = $_POST['lname'];
$sname = $_POST['sname'];
$company = $_POST['company'];
$department = $_POST['department'];
$position = $_POST['position'];
$ctel = $_POST['ctel'];
$ptel = $_POST['ptel'];
$email = $_POST['email'];
$sstate = $_POST['sstate'];

require('DB_Info.php');

if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

$sql="UPDATE staff SET sno='$sno',fname ='$fname',lname ='$lname',sname ='$sname', company ='$company', dpid ='$department', position ='$position', ctel ='$ctel', ptel ='$ptel', email ='$email', sstate ='$sstate' WHERE sid ='$sid'";

if (mysqli_query($conn, $sql)) {
    echo "<script>{alert('員工資料己更新了');location.href='S_Page.php'}</script>";
} else {
	echo "<script>{alert('更新錯誤');location.href='S_Page.php'}</script>";
}
?>

</body>
</html>