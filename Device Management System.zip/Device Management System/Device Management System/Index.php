<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>DMS</title>
<link rel="stylesheet" type="text/css" href="CSS/css_style.css"/>

<style type="text/css"> 

body
{ 
background:url(Image/background1.jpg);
background-size:100% 200%; 
}

#login_btn{
background:linear-gradient(yellow,green);
width:85px;	
height:30px;
margin-top:15px;
margin-bottom:15px;
text-align:center;
cursor:pointer;
}

h1{
	background-color:#87CEEB;
	margin-top:0px;
	padding-bottom:8px;
	padding-top:8px;
	border-radius:8px 8px 0px 0px;
	padding-left:1px;
}

</style> 

</head>
<body>
<?PHP
session_start();
$_SESSION["username"]="";
$_SESSION["role"]="";
?>
<font size="4">
<div id="login">

<center>
<h1><img src="Image/logo3.png" width="250";"></h1>
<form action="Config.php" method="post">
<br/>

<table>
<tr><th><td align="right"><b>用户名:</b></th><th><input type="text" id="login_txt" name="uname"></th></tr>
<tr><th><td align="right"><b>密码:</b></th><th><input type="password" id="login_txt" name="pwd"></th></tr>
<tr><th colspan="4"><input type="submit" id="login_btn" value="登入"></th></tr>
</table>
</form>

</center>

<img src="Image/logo.jpg" width="100" align="right";">
</div>
</font>
</body>
</html>