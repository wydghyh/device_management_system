<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Test Page</title>
<script>
function myFunction() {

var nameContent = document.getElementById('test').value;

<?php 

$test1  ="print'<script> nameContent </script>'";

require('DB_Info.php');
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}
$sql = "SELECT * FROM device inner join catalog where device.cid=catalog.cid and device.dstate='".$test1."'";
$result = mysqli_query($conn, $sql);
$List="";
if (mysqli_num_rows($result) > 0) {

    while($row = mysqli_fetch_assoc($result)) {
		
        $List.="
		<table>
		<tr>
		<th>设备编号 :".$row["did"]."</th>
		<th>类别 :".$row["cname"]."</th>
		<th>状态 :".$row["dstate"]."</th>
		<th>备注 :".$row["other"]."</th>
		</tr>
		</table>
		";
    }
	echo "document.getElementById('demo').innerHTML =' ".$List."';";
}

?>

}
</script>
</head>
<body>

<form>
<select name="state" id="test" onchange="myFunction()">
	<option value="all"selected>全部</option>
	<option value="使用中">使用中</option>
	<option value="闲置">闲置</option>
	<option value="损坏">损坏</option>
	<option value="报废">报废</option>
</select>
</form>
<p id="demo"> hi</p>
</body>
</html>
