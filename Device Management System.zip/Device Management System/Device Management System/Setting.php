﻿<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Untitled Document</title>
<style>
.set_btn{
	width:100%;
	background-color:transparent;
	border:none;
	font-size:18px;
	text-align:left;
}

th{
	font-size:18px;
	border-bottom:1px #999 dotted;
	padding-top:20px;
}
input[type=text] {
    width:200px;
    background-color:transparent;
    border: 2px solid #ccc;
    border-radius: 5px;
    font-size: 18px;
	margin:0 10px;
}
input[type=submit]{
	width:60px;
	height:25px;
	border:2px solid #CCC;
	background-color:#FFF;
	border-radius: 5px;
}
input[type=submit]:hover{
	background-color:#CCC;
	color:#FFF;
}
</style>
</head>

<body>
<table style="width:100%;">
  
  
  <tr><th><a href="U_List.php"><button class="set_btn"><b>用戶管理</b></button></a></th></tr>
  <tr><th><a href="departmentinfo.php"><button class="set_btn"><b>部门管理</b></button></a></th></tr>
  <tr><th><a href="deviceinfo.php"><button class="set_btn"><b>设备管理</b></button></a></th></tr>
 
</table>
</body>
</html>