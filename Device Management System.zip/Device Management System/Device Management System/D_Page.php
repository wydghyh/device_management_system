﻿<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Untitled Document</title>
<link rel="stylesheet" type="text/css" href="CSS/css_style.css"/>

<style type="text/css"> 
#add{
	line-height:80%;
	

	
}
</style> 

</head>

<body>
<a href="borrowinginfo.php"><button id='set_btn'><b>查看借用动态</b></button></a>
<div id="add">


<form action="D_List_2.php" method="post" target="DFrame">
<label for="fname"><b>姓名：</b></label>
<input type="text" name="fname" id="ds_page" value="" placeholder=" 请输入英文姓名">
&nbsp;

<form action="D_List_2.php" method="post" target="DFrame">
<label for="brand"><b>品牌：</b></label>
<input type="text" name="brand" id="ds_page" value="" placeholder=" 请输入品牌">
&nbsp;
<form action="D_List_2.php" method="post" target="DFrame">
<label for="series"><b>系列：</b></label>
<input type="text" name="series" id="ds_page" value="" placeholder=" 请输入系列">
&nbsp;
<form action="D_List_2.php" method="post" target="DFrame">
<label for="model"><b>型号：</b></label>
<input type="text" name="model" id="ds_page" value="" placeholder=" 请输入型号">
&nbsp;
<form action="D_List_2.php" method="post" target="DFrame">
<label for="location"><b>位置：</b></label>
<input type="text" name="location" id="ds_page" value="" placeholder=" 请输入网络位置">
&nbsp;
<form action="D_List_2.php" method="post" target="DFrame">
<label for="sn"><b>设备序列号：</b></label>
<input type="text" name="sn" id="ds_page" value="" placeholder=" 请输入设备序列号">
&nbsp;
<form action="D_List_2.php" method="post" target="DFrame">
<label for="did"><b>技术部设备号：</b></label>
<input type="text" name="did" id="ds_page" value="" placeholder=" 请输入设备号">
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
<form action="D_List_2.php" method="post" target="DFrame">
<label for="asiano"><b>财务部设备号：</b></label>
<input type="text" name="asiano" id="ds_page" value="" placeholder=" 请输入设备号">
&nbsp;
<form action="D_List_2.php" method="post" target="DFrame">
<label for="assnum"><b>财务部资产编号：</b></label>
<input type="text" name="assnum" id="ds_page" value="" placeholder=" 请输入资产编号">
&nbsp;

&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
</div>

<?php

require('DB_Info.php');

// Check connection
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}


$sql = "SELECT * FROM catalog";
$result = mysqli_query($conn, $sql);
$Combo="<label for=catalog><b>类别：</b></label><select name=catalog id=ds_page><option value=all selected>全部</option>";

if (mysqli_num_rows($result) > 0) {
    // output data of each row
    while($row = mysqli_fetch_assoc($result)) {
        $Combo.="<option value=".$row["cid"].">". $row["cname"] . "</option>";
    }
} else {
    echo "Error";
}
echo $Combo."</select>";

mysqli_close($conn);
?>

<?php

require('DB_Info.php');

// Check connection
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}


$sql = "SELECT * FROM department  order by dpname";
$result = mysqli_query($conn, $sql);
$Combo="<label for=department><b>部门：</b></label><select name=dpid id=ds_page><option value=all selected>全部</option>";

if (mysqli_num_rows($result) > 0) {
    // output data of each row
    while($row = mysqli_fetch_assoc($result)) {
        $Combo.="<option value=".$row["dpid"].">". $row["dpname"] . "</option>";
    }
} else {
    echo "Error";
}
echo $Combo."</select>";

mysqli_close($conn);
?>



<label for="state"><b>状态：</b></label>
<select name="state" id="ds_page">
	<option value="all"selected>全部</option>
	<option value="使用中">使用中</option>
	<option value="闲置">闲置</option>
	<option value="损坏">损坏</option>
	<option value="报废">报废</option>
</select>
<label for="company"><b>所属公司：</b></label>
<select name="company" id="ds_page">
	<option value="all"selected>全部</option>
	<option value="Hong Kong">Hong Kong</option>
	<option value="ASIA">ASIA</option>
</select>
&nbsp;
<input type="submit" value=" 搜寻 ">

<input type="submit" onclick="action='D_Add.php',target='C_Frame'"  value="新建设备" >

		
</form>

<br />
<iframe src="D_List.php" name="DFrame" width="100%" height="725px" style="border:none;"></iframe>

</body>
</html>