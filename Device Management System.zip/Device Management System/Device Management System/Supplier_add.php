﻿<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Untitled Document</title>
<link rel="stylesheet" type="text/css" href="CSS/css_style.css"/>
<style>
	table{border-radius: 20px;
	border:#999 solid 3px;
	padding:30px 30px 30px 30px;
	margin-top:50px;
}

#table_size_2{
	width:250px;
	height:50px;
}
</style>
</head>
<body>
<?php

require('DB_Info.php');

// Check connection
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}



echo"<form action=supplier_Create.php method=POST><center><table style='text-align:left;'><tr><th></th><th>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;新建供应商</th></tr>
<tr><th></th></tr>
<tr><th></th></tr>
<tr><th></th></tr>
<tr><th></th></tr>
        
        <tr><th><span style='text-align:left;'>*供应商类型：</span></th><td><input type=text name=suppliertype id='table_size_1'></td></tr>
	<tr><th><span style='text-align:left;'>*供应商名称：</span></th><td><input type=text name=suppliername id='table_size_1'></td></tr>
	<tr><th><span style='text-align:left;'>*负责人：</span></th><td><input type=text name=supplierperson id='table_size_1'></td></tr>
        <tr><th><span style='text-align:left;'>*电话：</span></th><td><input type=text name=suppliertel id='table_size_1'></td></tr>
	<tr><th><span style='text-align:left;'>*Email：</span></th><td><input type=text name=supplieremail id='table_size_1'></td></tr>
	<tr><th><span style='text-align:left;'>*公司介绍：</span></th><th><textarea name=supplierinfo maxlength='5000' id='table_size_2'></textarea></th></tr>
	 
   
<tr><tr></tr>
<tr></tr>
<tr></tr>
<tr></tr>
<th></th><th>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<span style='text-align:left;'><input type=submit name=submit value=创建></span><input type=submit name=Submit onclick=javascript:history.back(-1); value=返回></th>
<th></th></tr></table></center>



</from>";

?>
</body>
</html>