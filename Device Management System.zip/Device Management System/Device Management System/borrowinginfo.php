﻿<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Device List</title>
<link rel="stylesheet" type="text/css" href="CSS/css_style.css"/>
</head>

<body>

<?php

require('DB_Info.php');
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

$sql = "select * from ( select did, rid,sid,ltime,rtime from record where rid in (select max(rid) from record group by did ) ) r left outer join staff s on s.sid = r.sid right outer join device d on r.did = d.did ORDER BY `r`.`rid` DESC";
$result = mysqli_query($conn, $sql);
$List="";

if (mysqli_num_rows($result) > 0) {
    // output data of each row
    while($row = mysqli_fetch_assoc($result)) {
		//Click On List
		if($row["dstate"]=="使用中"){
			$color="#4682B4";
		}else{
			$color="#000";
		}
		
        $List.="
		<div id='li'>
		<form action='D_Info.php' method='post' target=C_Frame>
		<input type='submit' value=''>
		<input type='hidden' name='did' value='".$row["did"]."'>
		</form>
		<table style='width:100%; text-align:left;color:#999;'>
		<tr><th style='width:100px;'>姓名 : <span style='color:".$color.";'>".$row["fname"]." ".$row["lname"]." ".$row["sname"]."</span></th>
		<th style='width:120px;'>型号 : <span style='color:".$color.";'>".$row["model"]."</span>
		</th><th style='width:80px;'>状态 : <span style='color:".$color.";'>".$row["dstate"]."</span></th></tr>
                 </th><th style='width:80px;'>借用日期 : <span style='color:".$color.";'>".$row["ltime"]."</span></th></tr>
                 </th><th style='width:80px;'>归还日期 : <span style='color:".$color.";'>".$row["rtime"]."</span></th></tr>
		</table>
		</div>";
  }
	echo $List;
} else {
    echo "目前尚未有任何设备! 请增建设备";
}

mysqli_close($conn);
?>

</body>
</html>