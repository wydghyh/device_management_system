﻿<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<link rel="stylesheet" href="main.css">
<title>supplier_update</title>
</head>

<body>
<?php
session_start();


$supplierid = $_POST['supplierid'];
$suppliertype = $_POST['suppliertype'];
$suppliername = $_POST['suppliername'];
$supplierperson = $_POST['supplierperson'];
$suppliertel= $_POST['suppliertel'];
$supplieraddress= $_POST['supplieraddress'];
$Fax= $_POST['Fax'];
$supplieremail = $_POST['supplieremail'];
$supplierinfo = $_POST['supplierinfo'];


require('DB_Info.php');

if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}


$sql="UPDATE supplier SET suppliertype ='$suppliertype',suppliername ='$suppliername',Fax ='$Fax',supplierperson='$supplierperson',supplieraddress ='$supplieraddress',suppliertel ='$suppliertel',supplieremail ='$supplieremail',supplierinfo='$supplierinfo' WHERE supplierid ='$supplierid'";

if (mysqli_query($conn, $sql)) {
    echo "<script>{alert('供应商资料已经更新');location.href='supplier_Info.php?supplierid=$supplierid'}</script>";
} else {
	echo "<script>{alert('更新错误');location.href='Supplier_Edit.php'}</script>";
}

?>

</body>
</html>