﻿<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Untitled Document</title>
</head>

<body>
<?PHP
$sid = $_POST['sid'];

require('DB_Info.php');

$sql="DELETE FROM staff WHERE sid='$sid'";

if (mysqli_query($conn, $sql)) {
    echo "<script>{alert('員工資料已刪除');location.href='S_Page.php'}</script>";
} else {
	echo "<script>{alert('員工資料未能刪除');location.href='S_Page.php'}</script>";
}

?>
</body>
</html>