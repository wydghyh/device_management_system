<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Untitled Document</title>

<style>
*{
	font-size:18px;
}
input[type=submit]{
	border:none;
	border-bottom:#CCC 3px solid;
	background-color: transparent;
}
select{
    width:150px;
	border:none;
	border-bottom:#CCC 1px solid;
}
input[type=text] {
    width:150px;
    box-sizing: border-box;
    border: 2px solid #ccc;
    border-radius: 4px;
    background-color: white;
    background-position: 10px 10px; 
    background-repeat: no-repeat;
}
input[type=password] {
    width:150px;
    box-sizing: border-box;
    border: 2px solid #ccc;
    border-radius: 4px;
    background-color: white;
    background-position: 10px 10px; 
    background-repeat: no-repeat;
}
</style>
</head>
<body>
<?php

echo"<form action=U_Create.php method=POST><center><table>
	<tr><th>*用戶名稱</th><td><input type=text name=uname></td></tr>
	<tr><th>*密碼</th><td><input type=password name=pwd></td></tr>
	<tr><th>角色</th><td><select name=role><option vale='管理員'>管理員</option><option vale='一般用戶'>一般用戶</option></select></td></tr>
	</table><p><input type=submit name=submit value=Create></center></from>";
?>
</body>
</html>