﻿<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>supplier_deletet</title>
</head>

<body>
<script>{confirm('Are you sure to delete?');}</script>
<?PHP
$supplierid = $_POST['supplierid'];

require('DB_Info.php');

$sql="DELETE FROM supplier WHERE supplierid='$supplierid'";

if (mysqli_query($conn, $sql)) {
    echo "<script>{alert('供应商信息已经被删除！');location.href='Supplier_Page.php'}</script>";
} else {
	echo "<script>{alert('系统出现问题');location.href='Supplier_Page.php'}</script>";
}

?>
</body>
</html>