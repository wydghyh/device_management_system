﻿<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>goods_edit</title>
<style>
table{border-radius: 20px;
	border:#999 solid 3px;
	padding:50px 50px 50px 50px;
	margin-top:25px;
}
</style>
<link rel="stylesheet" type="text/css" href="CSS/css_style.css"/>
</head>
<body>
<?php

require('DB_Info.php');

if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}


$goodsid=$_POST['goodsid'];


  $supplierid = $_POST['supplierid'];








$sql = "select * from goods inner join supplier where goods.supplierid=supplier.supplierid and goods.goodsid='$goodsid'";
$result = mysqli_query($conn, $sql);
$List="<center><form action=goods_Update.php method=POST><table style='text-align:left;'>";

if (mysqli_num_rows($result) > 0) {
	while($row = mysqli_fetch_assoc($result)) {
		$List.="
                <tr><th>公司编号</th><td>".$row["supplierid"]."</td></tr>
                <tr><th>所属公司</th><td>".$row["suppliername"]."</td></tr>
                 <tr><th>商品编号</th><td>".$row["goodsid"]."</td></tr>
                <tr><th>商品名称</th><td><input type=text id='table_size_1' name=goodsname value='".$row["goodsname"]."'></td></tr>
		<tr><th>数量</th><td><input type=text id='table_size_1' name=goodsnum value='".$row["goodsnum"]."'></td></tr>
                <tr><th>购买价格</th><td><input type=text id='table_size_1' name=goodsprice value='".$row["goodsprice"]."'></td></tr>
		<tr><th>购买日期</th><td><input type=text id='table_size_1' name=goodsdate value='".$row["goodsdate"]."'></td></tr>
		
		<tr><td></td></tr>
	<tr><td></td></tr>
	<tr><td></td></tr>
	<tr><td></td></tr>
	<tr><td></td></tr>
	<tr><td></td></tr>
	<tr><td></td></tr>
	<tr><td></td></tr>
	<tr><td></td></tr>
		<tr><th></th><th>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                 <input type=hidden name=goodsid value='$goodsid'><input type=hidden name=supplierid value='$supplierid'><input type=submit name=submit value=提交 >

                <form action=goods_Update.php method=POST><input type=hidden name=goodsid value=".$row["goodsid"]."><input type=submit name=Back value=返回></form>
		</th></tr>
		</table></center>
		";
	}
	echo $List;
} else {
    echo "系統出現故障 !!";
}
?>
</body>
</html>