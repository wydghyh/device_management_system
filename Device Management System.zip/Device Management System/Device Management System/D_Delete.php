﻿<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Untitled Document</title>
</head>

<body>
<script>{confirm('Are you sure to delete?');}</script>
<?PHP
$did = $_POST['did'];

require('DB_Info.php');

$sql="DELETE FROM device WHERE did='$did'";

if (mysqli_query($conn, $sql)) {
    echo "<script>{alert('設備已被刪除.');location.href='D_Page.php'}</script>";
} else {
	echo "<script>{alert('系統出現問題');location.href='D_Page.php'}</script>";
}

?>
</body>
</html>