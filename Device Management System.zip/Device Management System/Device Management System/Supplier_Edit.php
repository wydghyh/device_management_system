﻿<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Untitled Document</title>
<style>
table{border-radius: 20px;
	border:#999 solid 3px;
	padding:50px 50px 50px 50px;
	margin-top:25px;
}
</style>
<link rel="stylesheet" type="text/css" href="CSS/css_style.css"/>
</head>
<body>
<?php

require('DB_Info.php');

if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

$sql = "SELECT * FROM supplier";
$result = mysqli_query($conn, $sql);
$supplierid=$_POST['supplierid'];

if ($supplierid=='') {
  $supplierid = $_GET['supplierid'];
}



$sql = "SELECT * FROM supplier where supplierid='$supplierid'";
$result = mysqli_query($conn, $sql);
$List="<center><form action=Supplier_Update.php method=POST><table style='text-align:left;'>";

if (mysqli_num_rows($result) > 0) {
	while($row = mysqli_fetch_assoc($result)) {
		$List.="
                <tr><th>供应商编号</th><td>".$row["supplierid"]."</td></tr>
		
                <tr><th>供应商名称</th><td><input type=text id='table_size_1' name=suppliername value='".$row["suppliername"]."'></td></tr>
                <tr><th>供应商主营</th><td><input type=text id='table_size_1' name=suppliertype value='".$row["suppliertype"]."'></td></tr>
                 <tr><th>地址</th><td><textarea type=text name=supplieraddress value='".$row["supplieraddress"]."' maxlength='5000' id='table_size_1'>".$row["supplieraddress"]."</textarea></td></tr>
		<tr><th>负责人</th><td><input type=text id='table_size_1' name=supplierperson value='".$row["supplierperson"]."'></td></tr>
		<tr><th>电话</th><td><input type=text id='table_size_1' name=suppliertel value='".$row["suppliertel"]."'></td></tr>
                <tr><th>Email</th><td><input type=text id='table_size_1' name=supplieremail value='".$row["supplieremail"]."'></td></tr>
                <tr><th>Fax</th><td><input type=text id='table_size_1' name=Fax value='".$row["Fax"]."'></td></tr>
		<tr><th>公司介绍</th><td><textarea type=text name=supplierinfo value='".$row["supplierinfo"]."' maxlength='5000' id='table_size_1'>".$row["supplierinfo"]."</textarea></td></tr>
		<tr><td></td></tr>
	<tr><td></td></tr>
	<tr><td></td></tr>
	<tr><td></td></tr>
	<tr><td></td></tr>
	<tr><td></td></tr>
	<tr><td></td></tr>
	<tr><td></td></tr>
	<tr><td></td></tr>
		<tr><th></th><th>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                 <input type=hidden name=supplierid value='$supplierid'><input type=submit name=submit value=提交>
                <form action=supplier_Info.php method=POST><input type=hidden name=supplierid value=".$row["supplierid"]."><input type=submit name=Back value=返回></form>
		</th></tr>
		</table></center>
		";
	}
	echo $List;
} else {
    echo "系統出現故障 !!";
}
?>
</body>
</html>