﻿<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Device List</title>
<link rel="stylesheet" type="text/css" href="CSS/css_style.css"/>
<style type="text/css">

#one{width:260px;
height:180px;
margin:35px;
float:left;
border:2px solid #999;
	 padding:20px;
	border-radius:10px;
	position:relative;
	left:45px}

#one:hover{
	transition:1.0s;
	background-color:#B0C4DE;
}
#one input[type=submit]{
position:absolute;
	width:100%;
	top:0;
	left:0;
	height:200px;
	background-color: transparent;
	border:none;
}

</style>
</head>

<body>

<?php

require('DB_Info.php');
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

$sql = "select * from ( select did, rid,sid from record where rid in (select max(rid) from record group by did ) ) r left outer join staff s on s.sid = r.sid right outer join device d on r.did = d.did" ;
$result = mysqli_query($conn, $sql);
$List="";

if (mysqli_num_rows($result) > 0) {
    // output data of each row
    while($row = mysqli_fetch_assoc($result)) {
		//Click On List
		if($row["dstate"]=="使用中"){
			$color="#000080";
 $List.="
			<div id='one'>
		<form action='D_Info.php' method='post' target=C_Frame>
		<input type='submit' value=''>
		<input type='hidden' name='did' value='".$row["did"]."'>
		</form>
		<table style='text-align:left;color:#808080;table-layout:fixed;'>
               
                <tr> <th style='width:75px;'>使用人: </th><th><span style='color:".$color.";'>".$row["fname"]." ".$row["lname"]." ".$row["sname"]."</span></th></tr>	
		<tr><th style='width:75px;'>品牌: </th><th><span style='color:".$color.";'>".$row["brand"]."</span></th></tr>
                <tr><th style='width:75px;'>系列: </th><th><span style='color:".$color.";'>".$row["series"]."</span></th></tr>      
                <tr> <th style='width:75px;'>型号: </th><th><span style='color:".$color.";white-space:nowrap;display:block;width:150px;overflow:hidden;text-overflow:ellipsis;'>".$row["model"]."</span></th></tr>
		<tr><th style='width:75px;' >序列号: </th><th><span style='color:".$color.";'>".$row["sn"]."</span></th></tr>
		<tr><th style='width:75px;'>公司: </th><th><span style='color:".$color.";'>".$row["company"]."</span></th></tr>
                <tr><th style='width:75px;'>设备编号:</th><th><span style='color:".$color.";'>".$row["did"]."</span></th></tr>
		</table>
		</div>";
		}else{
			$color="#808080" ;
$List.="
			<div id='one'>
		<form action='D_Info.php' method='post' target=C_Frame>
		<input type='submit' value=''>
		<input type='hidden' name='did' value='".$row["did"]."'>
		</form>
		<table style='text-align:left;color:#808080;'>
               
                
		<tr><th>品牌: </th><th><span style='color:".$color.";'>".$row["brand"]."</span></th></tr>
                <tr><th>系列: </th><th><span style='color:".$color.";'>".$row["series"]."</span></th></tr>      
                <tr> <th>型号:</th><th><span style='color:".$color.";white-space:nowrap;display:block;width:150px;overflow:hidden;text-overflow:ellipsis;'>".$row["model"]."</span></th></tr>
		<tr><th>序列号: </th><th><span style='color:".$color.";'>".$row["sn"]."</span></th></tr>
		<tr><th>公司: </th><th><span style='color:".$color.";'>".$row["company"]."</span></th></tr>
                <tr><th>设备编号: </th><th><span style='color:".$color.";'>".$row["did"]."</span></th></tr>
		</table>
		</div>";
               }

             
		
        
  }
	echo $List;
} else {
    echo "目前尚未有任何设备! 请增建设备";
}

mysqli_close($conn);
?>

</body>
</html>