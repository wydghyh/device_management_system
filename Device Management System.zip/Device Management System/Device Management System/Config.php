<!-- login頁面所輸入資料將連結到database中admin或member核對登入身份,及彈出登入身份的提示信息 -->
<?php
session_start();

$uname = $_POST['uname'];
$pwd = $_POST['pwd'];


require('DB_Info.php');

if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

$sql="SELECT * FROM user WHERE uname = '$uname' AND pwd = '$pwd'";
$result = mysqli_query($conn, $sql);

if (mysqli_num_rows($result) > 0){
	while($row = mysqli_fetch_assoc($result)) {
		$_SESSION["role"]=$row["role"];
		$_SESSION["username"]=$row["uname"];
		$uname = $row["uname"];
	}
	echo "<script>{alert('$uname, 歡迎到訪 ');window.parent.location='MainPage.php'}</script>";
}else{
	echo "<script>{alert('名稱 或 密碼 錯誤');location.href='Index.php'}</script>";
}
?>