﻿<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<link rel="stylesheet" href="main.css">
<title>Untitled Document</title>
</head>

<body>
<?php
session_start();


$dpid = $_POST['dpid'];
$dpname = $_POST['dpname'];

require('DB_Info.php');

if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}


$sql="UPDATE department SET dpname ='$dpname' WHERE dpid ='$dpid'";

if (mysqli_query($conn, $sql)) {
    echo "<script>{alert('部门资料己更新了');location.href='departmentinfo.php'}</script>";
} else {
	echo "<script>{alert('更新错误');location.href='departmentinfo.php'}</script>";
}

?>

</body>
</html>