﻿<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>S_Info</title>
<link rel="stylesheet" type="text/css" href="CSS/css_style.css"/>
<style>

tr:nth-child(even){
	background-color: #F0F8FF;
}

th{
	text-align:left;
}
#Staff{
	position:relative;
margin-left:5%;
float:left;
	width:33%;
height:350px;
	border-radius: 10px;
	border:#999 solid 3px;
	overflow:auto;
	margin-top:70px;
	padding:50px 10px 10px 0;
	line-height:120%;

}
#StaffD{
	position:relative;
margin-left:35px;
float:left;
	width:45%;
	height:350px;
	border-radius: 10px;
	border:#999 solid 3px;
	overflow:auto;
	margin-top:70px;
	padding:50px 10px 10px 0;
	line-height:120%;
margin-bottom:80px;
}
#StaffD2{
	position:relative;
margin-left:30%;

	width:45%;
	height:350px;
	border-radius: 10px;
	border:#999 solid 3px;
	overflow:auto;
	
	padding:50px 10px 10px 0;
	line-height:120%;

}
table{
	width:85%;
}
@media screen and (max-width: 800px) {
    #Staff{ width:80%;
	border-radius: 10px;
	border:#999 solid 3px;
	overflow:auto;
	margin-top:30px;
	padding:8px 0 8x 0;
	margin-left:9%;
	line-height:120%;}
       
	   #StaffD { width:80%;
	float:left;
margin-left:8%;
	border-radius: 10px;
	border:#999 solid 3px;
	
	 word-break: break-all;
	padding:5px;
	line-height:120%;}
	
	#StaffD2 { width:80%;
	float:left;
	height:120px;
margin-left:8%;
	border-radius: 10px;
	border:#999 solid 3px;
	overflow:auto;
	padding:5px;
	line-height:120%;}
}
</style>
</head>

<body>


<div id="Staff">
<?PHP
session_cache_limiter('private, must-revalidate');
session_start();
$role=$_SESSION["role"];

$sid = $_POST['sid'];

require('DB_Info.php');


// Check connection
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}


$sql = "SELECT * FROM staff inner join department WHERE staff.dpid=department.dpid and staff.sid=".$sid;
$result = mysqli_query($conn, $sql);
$List="<center><b>员工资料</b><p><p><table style='text-align:left;color:#585858;'>";

	if (mysqli_num_rows($result) > 0) {
		while($row = mysqli_fetch_assoc($result)) {
			$List.="
			<tr><th>员工编号</th><td><span style='color:".black.";font-weight:".bold.";'>".$row["sno"]."</span></td></tr>
			<tr><th>员工名称</th><td><span style='color:".black.";font-weight:".bold.";'>".$row["fname"]." ".$row["lname"]." ".$row["sname"]."</span></td></tr>
			<tr><th>公司</th><td><span style='color:".black.";font-weight:".bold.";'>".$row["company"]."</span></td></tr>
			<tr><th>部门</th><td><span style='color:".black.";font-weight:".bold.";'>".$row["dpname"]."</span></td></tr>
			<tr><th>职位</th><td><span style='color:".black.";font-weight:".bold.";'>".$row["position"]."</span></td></tr>
			<tr><th>公司电话</th><td><span style='color:".black.";font-weight:".bold.";'>".$row["ctel"]."</span></td></tr>
			<tr><th>手提电话</th><td><span style='color:".black.";font-weight:".bold.";'>".$row["ptel"]."</span></td></tr>
			<tr><th>E-mail</th><td><span style='color:".black.";font-weight:".bold.";'>".$row["email"]."</span></td></tr>
			<tr><th>状态</th><td><span style='color:".black.";font-weight:".bold.";'>".$row["sstate"]."</span></td></tr>
			</table></center>
			";
			if($role=="管理員"or $role=="员工管理者"){
			$List.="<br /><center><table id='table_size_1'><tr></tr>
			<tr></tr>
			<tr></tr>
			<tr></tr>
			<tr>
			<th><form action=S_Edit.php method=POST><input type=hidden name=sid value=".$row["sid"]."><input type=submit name=Edit value=Edit></form></th>
			<th><form action=S_Delete.php method=POST><input type=hidden name=sid value=".$row["sid"]."><input type=submit name=Delete value=Delete></form></th>
			<th><input type=submit name=Submit onclick=javascript:history.back(-1); value=Back></th>
			</tr></table></center>";
			}
	}
	echo $List;

} else {
    echo "系統出現故障 !!";
}

?>
</div>





<div id="StaffD">
<?php
session_cache_limiter('private, must-revalidate');
session_start();
$role=$_SESSION["role"];

$sid = $_POST['sid'];


require('DB_Info.php');


// Check connection
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

$sql="select * from ( select did, rid,sid,ltime from record where rid in (select max(rid) from record group by did ) ) r left outer join staff s on s.sid = r.sid right outer join device d on r.did = d.did where  dstate='使用中' and r.sid=".$sid;
$result= mysqli_query($conn,$sql);
if($role=="管理員"or $role=="一般用戶"){
$List="<center><table style='text-align:left;color:#585858;'><tr><th>该员工当前借用设备资料</th></tr>
<tr><th>品牌</th><th>设备名称</th><th>序列号</th><th>所属公司</th><th>借用时间</th></tr>";

if (mysqli_num_rows($result) > 0) {
    // output data of each row
    while($row = mysqli_fetch_assoc($result)) {


        $List.="
		<tr><td><span style='color:".black.";font-weight:".bold.";'>".$row["brand"]."</span></td>  <td><span style='color:".black.";font-weight:".bold.";'>".$row["model"]."</span></td> <td><span style='color:".black.";
font-weight:".bold.";'>".$row["sn"]."</span></td> <td><span style='color:".black.";font-weight:".bold.";'>".$row["company"]."</span></td></td><td><span style='color:".black.";font-weight:".bold.";'>".$row["ltime"]."</span></td></tr>";
    }
	
	$List.="</table></center>";

	echo $List;
	
} else {
    echo "该员工无借阅记录";
}}

mysqli_close($conn);
?>
</div>

<div id="StaffD2">
<?php
session_cache_limiter('private, must-revalidate');
session_start();
$role=$_SESSION["role"];

$sid = $_POST['sid'];


require('DB_Info.php');


// Check connection
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

$sql="select *  from record  left outer join staff  on staff.sid = record.sid right outer join device on record.did = device.did where record.rtime is not null and record.sid=".$sid;
$result= mysqli_query($conn,$sql);
if($role=="管理員"or $role=="一般用戶"){
$List="<center><table style='text-align:left;color:#585858;'><tr><th>该员工历史借用设备资料</th></tr>
<tr><th>品牌</th><th>设备名称</th><th>序列号</th><th>所属公司</th><th>借用时间</th><th>归还时间</th></tr>";

if (mysqli_num_rows($result) > 0) {
    // output data of each row
    while($row = mysqli_fetch_assoc($result)) {


        $List.="
		<tr><td><span style='color:".black.";font-weight:".bold.";'>".$row["brand"]."</span></td>  <td><span style='color:".black.";font-weight:".bold.";'>".$row["model"]."</span></td> <td><span style='color:".black.";
font-weight:".bold.";'>".$row["sn"]."</span></td> <td><span style='color:".black.";font-weight:".bold.";'>".$row["company"]."</span></td><td><span style='color:".black.";font-weight:".bold.";'>".$row["ltime"]."</span></td><td><span style='color:".black.";font-weight:".bold.";'>".$row["rtime"]."</span></td></tr>";
    }
	
	$List.="</table></center>";

	echo $List;
	
} else {
    echo "该员工无历史借阅记录";
}}

mysqli_close($conn);
?>
</div>










</body>
</html>