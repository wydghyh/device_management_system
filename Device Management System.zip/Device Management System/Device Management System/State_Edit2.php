﻿<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Untitled Document</title>
<style>
*{
	font-size:18px;
}
input[type=submit]{
	border:none;
	border-bottom:#CCC 3px solid;
	background-color: transparent;
}
select{
    width:200px;
	border:none;
	border-bottom:#CCC 1px solid;
}
input[type=text] {
    width:200px;
    box-sizing: border-box;
    border: 2px solid #ccc;
    border-radius: 4px;
    background-color: white;
    background-position: 10px 10px; 
    background-repeat: no-repeat;
}

</style>
</head>
<body>
<?PHP
$did = $_POST['did'];
$combobox=$_POST["combobox"];

require('DB_Info.php');

if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}
/*-----------------------------------------^連接數據庫^-----------------------------------------*/
$sql = "SELECT * FROM device WHERE did='$did'";
$result = mysqli_query($conn, $sql);

if (mysqli_num_rows($result) > 0) {
    while($row = mysqli_fetch_assoc($result)) {
		$dstate=$row['dstate'];
	}
} else {
	echo "錯誤";
}
/*-----------------------------------------^讀取目前設備狀態^-----------------------------------------*/
$sql = "SELECT * FROM staff order by sid";
$result = mysqli_query($conn, $sql);
$Staffbox="";
if (mysqli_num_rows($result) > 0) {
    while($row = mysqli_fetch_assoc($result)) {
		$Staffbox.="<option value=".$row["sid"].">".$row["sno"]." | ".$row["sname"]."</option>";
	}
} else {
	echo "錯誤";
}
/*-----------------------------------------^建立Staff_Combobox^-----------------------------------------*/
if($combobox=="使用中"){
	if($dstate=="使用中"){
		$List="<form action='State_Update.php' method=post><center><table>
		<tr><th>歸還日期:</th><th><input type='text' name=rtime value='".date("d/m/Y")."'></th></tr><p>";
	}else{
		$List="<form action='State_Update.php' method=post><center><table>";
	}
	$List.="<tr><th>借用員工:</th><th><select name=sid>'$Staffbox'</select></th></tr>
	<tr><th>借用日期:</th><th><input type='text' name=ltime value='".date("d/m/Y")."'></th></tr>
	</table>
	<p><input type=hidden name=did value='$did'><input type=hidden name=combobox value='$combobox'><input type=submit name=submit value=submit></from>
	</center>	";
	
	echo $List;
}else{
	if($dstate=="使用中"){
		$List="<form action='State_Update.php' method=post><center><table>
		<tr><th>歸還日期:</th><th><input type='text' name=rtime value='".date("d/m/Y")."'></th></tr><p>
		</table>
		<p><input type=hidden name=did value='$did'><input type=hidden name=combobox value='$combobox'><input type=submit name=submit value=submit></from>
		</center>";
		echo $List;
	}else{
		$sql="UPDATE device SET dstate='$combobox' WHERE did='$did'";

		if (mysqli_query($conn, $sql)) {
		    echo "<script>{alert('狀態己更新了');location.href='D_List.php'}</script>";
		} else {
			echo "<script>{alert('更新錯誤');location.href='D_List.php'}</script>";
		}
	}
}
/*----------------------------------------------------------------------------------*/

?>
</body>
</html>