<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Untitled Document</title>
</head>

<body>
<?php
$sno=$_POST["sno"];
$sname=$_POST["sname"];
$fname=$_POST["fname"];
$lname=$_POST["lname"];
$company=$_POST["company"];
$dpid=$_POST["dpid"];
$position=$_POST["position"];
$ctel=$_POST["ctel"];
$ptel=$_POST["ptel"];
$email=$_POST["email"];

require('DB_Info.php');

if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

$sql = "SELECT * FROM staff where sno='$sno'";
$result = mysqli_query($conn, $sql);

if (mysqli_num_rows($result) > 0) {
	 echo "<script>{alert('員工號相同');location.href='S_Add.php'}</script>";
}else{
	$sql="INSERT INTO staff (sno,sname,fname,lname,company,dpid,position,ctel,ptel,email,sstate) VALUES ('$sno','$sname','$fname','$lname','$company','$dpid','$position','$ctel','$ptel','$email','在职')";
	if (mysqli_query($conn, $sql)) {
	    echo "<script>{alert('員工增加了');location.href='S_Page.php'}</script>";
	} else {
		echo "<script>{alert('員工尚未增加');location.href='S_Add.php'}</script>";
	}
}

?>
</body>
</html>