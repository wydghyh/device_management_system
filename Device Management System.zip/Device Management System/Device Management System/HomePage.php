﻿<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Untitled Document</title>
<link rel="stylesheet" type="text/css" href="CSS/css_style.css"/>

<style type="text/css"> 

body
{ 
background:url(Image/background1.jpg);
background-size:100% 250%; 

}
h1{
	text-align:right;
	font-style:italic;
	margin-top:30px;
	margin-right:30px;
	
}

</style> 

</head>

<body>
<h1><font style="color:white; font-size:35px">欢迎使用设备管理系统</font></h2>
<?php
session_start();
$role=$_SESSION["role"];
if($role=="管理員" or $role=="一般用戶"){
echo"
<div id='home_btn'><a href='D_Page.php' target='C_Frame'><img src='Image/btn_menu.png' width=100%><div id='btn_span'>设备</div></a></div>";
}
?>
<div id="home_btn"><a href="Supplier_Page.php" target="C_Frame"><img src="Image/btn_menu.png" width="100%"><div id="btn_span">供应商</div></a></div>

<div id="home_btn"><a href="S_Page.php" target="C_Frame"><img src="Image/btn_menu.png" width="100%"><div id="btn_span">员工</div></a></div>

<?php
session_start();
$role=$_SESSION["role"];
if($role=="管理員"){
echo"
<div id='home_btn'><a href='Setting.php' target='C_Frame'><img src='Image/btn_menu.png' width=100%><div id='btn_span'>设置</div></a></div>";
}
?>

</body>

</html>
