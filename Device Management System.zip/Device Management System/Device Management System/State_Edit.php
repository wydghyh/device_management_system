﻿<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Untitled Document</title>
<style>
*{
	font-size:15px;
}
body{
	width:320px;
	margin:0 auto;
	margin-top:50px;
border-radius: 20px;
	border:#999 solid 3px;	
	padding:20px 20px 20px 20px;
}
h1{font-weight:bold;}
p{
		line-height:0em;
	}
input[type=submit]{
	background-color: transparent;
}

input[type=text] {
    width:200px;
    box-sizing: border-box;
    border: 2px solid #ccc;
    border-radius: 4px;
    background-color: white;
    background-position: 10px 10px; 
    background-repeat: no-repeat;
}
input[type=submit]:hover{
	background-color:#3399CC;
	color:#FFF;
}

input[type=submit]{
	border:2px solid #999;
	background-color:#FFF;
	border-radius:5px;
	margin-left:-30px;
}


</style>
</head>
<body>
<?PHP
$did = $_POST['did'];
$combobox=$_POST["combobox"];

require('DB_Info.php');

if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}
/*-----------------------------------------^連接數據庫^-----------------------------------------*/
$sql = "SELECT * FROM device WHERE did='$did'";
$result = mysqli_query($conn, $sql);

if (mysqli_num_rows($result) > 0) {
    while($row = mysqli_fetch_assoc($result)) {
		$dstate=$row['dstate'];		
	}
} else {
	echo "錯誤";
}
/*-----------------------------------------^讀取目前設備狀態^-----------------------------------------*/


if($combobox=="使用中"){
	if($dstate=="使用中"){
		$List="<form action='State_Update.php' method=post><h1>
		归还日期:<input type='text' name=rtime value='".date("d/m/Y")."'></h1>";
	$List.="
<h1>借用日期:</th><td><input type='text' name=ltime value='".date("d/m/Y")."'></h1>
	<h1>借用员工:</h1>
	";echo $List;}	else {
	$List="<form action='State_Update.php' method=post>";
	$List.="
<h1>借用日期:</th><td><input type='text' name=ltime value='".date("d/m/Y")."'></h1>
	<h1>借用员工:</h1>
	";echo $List;
}
	
$sql = "SELECT * FROM staff where sstate='在职' order by fname";
$result = mysqli_query($conn, $sql);
$List="";
if (mysqli_num_rows($result) > 0) {		
	while($row = mysqli_fetch_assoc($result)) {							
		$List="<form action='State_Update.php' method=post>
		<p><input type='radio' name=sid value='".$row["sid"]."'>".$row["fname"]." ".$row["lname"]." ".$row["sname"]."</p>";	
	echo $List;
	}$List.="
	<center><table><tr><td></td></tr>
	<tr><td></td></tr>
	<tr><td></td></tr>
	<tr><th></th><th><input type=hidden name=did value='$did'><input type=hidden name=combobox value='$combobox'><input type=submit name=submit value=提交 class='onebutton'></th></tr>
	</table></center>	";	
	echo $List;
} else {
	echo "錯誤";
}
}

if($combobox!=="使用中"){
	if($dstate=="使用中"){
		$List="<form action='State_Update.php' method=post>
		<h1>归还日期:<input type='text' name=rtime value='".date("d/m/Y")."'><h1>
		<center><table><tr><td></td></tr>
	<tr><td></td></tr>
		<tr><th></th><th><input type=hidden name=did value='$did'><input type=hidden name=combobox value='$combobox'><input type=submit name=submit value=提交 class='onebutton'></th></tr></from>
		</table></center>";
		echo $List;
	}else{
		$sql="UPDATE device SET dstate='$combobox' WHERE did='$did'";

		if (mysqli_query($conn, $sql)) {
		    echo "<script>{alert('狀態己更新了');location.href='D_List.php'}</script>";
		} else {
			echo "<script>{alert('更新錯誤');location.href='D_List.php'}</script>";
		}
	}
}

/*----------------------------------------------------------------------------------*/

?>
</body>
</html>