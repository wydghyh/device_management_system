<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Untitled Document</title>
<style>
select{
	border:none;
	border-bottom:#CCC 1px solid;
	font-size:18px;
	margin:0 10px;
}
input[type=submit]{
	position:absolute;
	width:60px;
	height:25px;
	border:2px solid #CCC;
	background-color:#FFF;
	right:0;
	border-radius: 5px;
}
input[type=submit]:hover{
	background-color:#CCC;
	color:#FFF;
}

input[type=text] {
    width:100px;
    background-color:transparent;
    border: 2px solid #ccc;
    border-radius: 5px;
    font-size: 18px;
	margin:0 10px;
}
</style>
</head>

<body>
<form action="U_Add.php" method="post" target="C_Frame">
<input type="submit" value="+ Add">
</form>
<br />
<br />
<form action="U_List_2.php" method="post" target="UFrame">

<label for id="uname">用戶名稱:</label>

<input type="text" name="uname" id="uname" value="" placeholder=" ID">

<input type="submit" value="Search">

</form>

<br />
<iframe src="U_List.php" name="UFrame" width="100%" height="500px"  style="border:none;"></iframe>

</body>
</html>