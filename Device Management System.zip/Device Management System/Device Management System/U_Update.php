<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<link rel="stylesheet" href="main.css">
<title>Untitled Document</title>
</head>

<body>
<?php
session_start();
$user=$_SESSION["username"];
$role=$_SESSION["role"];
$uid = $_POST['uid'];
$pwd = $_POST['pwd'];

require('DB_Info.php');

if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

if($role=="管理員"){
$role = $_POST['role'];

$sql="UPDATE user SET pwd ='$pwd', role ='$role' WHERE uid ='$uid'";

if (mysqli_query($conn, $sql)) {
    echo "<script>{alert('用戶資料己更新了');location.href='U_List.php'}</script>";
} else {
	echo "<script>{alert('更新錯誤');location.href='U_List.php'}</script>";
}
}else{
	$pwd2 = $_POST['pwd2'];
	
	if($pwd==$pwd2){
		$sql="UPDATE user SET pwd ='$pwd' WHERE uid ='$uid'";
		
		if (mysqli_query($conn, $sql)) {
    		echo "<script>{alert('用戶資料己更新了');location.href='HomePage.php'}</script>";
		} else {
			echo "<script>{alert('舊密碼錯誤');location.href='HomePage.php'}</script>";
		}

	}else{
		echo "<script>{alert('確認密碼錯誤');location.href='HomePage.php'}</script>";
	}
}
?>

</body>
</html>