﻿<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Device List</title>
<style>

tr{
	height:30px;
	font-size:18px;
}

tr:nth-child(even){
	background-color: #f2f2f2;
}

tr:hover{
	background-color:#CCC;
}

input[type=submit]{
	border:none;
	background-color: transparent;
	font-size:16px;
	color:#900;
}

</style>

</head>

<body>

<tr><th><form action="Create_department.php" method="post" style="float: left;"><label for="ac">新建公司部门 : </label><input type="text" id="ac" name="dpname"><input type="submit" value="确认"></form></th></tr>

<?php

require('DB_Info.php');

if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}


$sql = "SELECT * FROM department ORDER BY dpname ASC";
$result = mysqli_query($conn, $sql);
$List="<table style=width:80%;>"."<tr><th>原部门名称</th><th>修改名称</th><th colspan='2'>修改</th></tr>";

if (mysqli_num_rows($result) > 0) {
    // output data of each row
    while($row = mysqli_fetch_assoc($result)) {
		//Click On List
        $List.="<tr><th>".$row["dpname"]."</th>
 <th><form action=department_Update.php method='POST'><input type='text' name='dpname'></th>
                 
<th><input type=submit name=Edit value=确定><input type=hidden name=dpid value='".$row["dpid"]."'></form></th>
                 
<th><form action=Department_Delete.php method='POST'> 
<input type=submit name=Delete value=删除><input type=hidden name=dpid value='".$row["dpid"]."'></form></th></tr>";
             		
		
    }
} else {
    echo "No Record";
}

$List.="</table>";
echo $List;

mysqli_close($conn);
?>
</body>
</html>