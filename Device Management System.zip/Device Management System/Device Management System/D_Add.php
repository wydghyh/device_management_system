﻿<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Untitled Document</title>
<link rel="stylesheet" type="text/css" href="CSS/css_style.css"/>
<style>
	table{border-radius: 20px;
	border:#999 solid 3px;
	padding:50px 50px 50px 50px;
	margin-top:50px;
}

</style>
</head>
<body>
<?php

require('DB_Info.php');

// Check connection
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}
$sql = "SELECT * FROM catalog";
$result = mysqli_query($conn, $sql);
$Catalog_box="";

if (mysqli_num_rows($result) > 0) {
    // output data of each row
    while($row = mysqli_fetch_assoc($result)) {
        $Catalog_box.="<option value=".$row["cid"].">". $row["cname"] . "</option>";
    }
} else {
    echo "0 results";
}

$Catalog_box.="</select>";

$Company_box="<option value='ASIA'>ASIA</option><option value='HONG KONG'>HONG KONG</option></select>";


echo"<form action=D_Create.php method=POST><center><table style='text-align:left;'><tr><th></th><th>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;新建设备</th></tr>
<tr><th></th></tr>
<tr><th></th></tr>
<tr><th></th></tr>
<tr><th></th></tr>
        
	<tr><th><span style='text-align:left;'>*类别</span></th><td><select name=cid id='table_size_1'><option></option>".$Catalog_box."</td></tr>
	<tr><th><span style='text-align:left;'>*品牌</span></th><td><input type=text style=text-transform:capitalize name=brand id='table_size_1'></td></tr>
        <tr><th><span style='text-align:left;'>*系列</span></th><td><input type=text style=text-transform:capitalize name=series  id='table_size_1'></td></tr>
	<tr><th><span style='text-align:left;'>*型号</span></th><td><input type=text style=text-transform:capitalize name=model id='table_size_1'></td></tr>
	<tr><th><span style='text-align:left;'>*序列号</span></th><td><input type=text style=text-transform:uppercase name=sn id='table_size_1'></td></tr>
	<tr><th><span style='text-align:left;'>*所属公司</span></th><td><select name=company id='table_size_1'><option></option>".$Company_box."</td></tr>
	<tr><th><span style='text-align:left;'>位置</span></th><td><input type=text style=text-transform:uppercase name=location id='table_size_1'></td></tr>
	<tr><th><span style='text-align:left;'>MAC物理地址</span></th><td><input type=text style=text-transform:uppercase name=mac id='table_size_1'></td></tr>
        <tr><th><span style='text-align:left;'>MAC网卡地址</span></th><td><input type=text style=text-transform:uppercase name=netmac id='table_size_1'></td></tr>
	<tr><th><span style='text-align:left;'>RAM</span></th><td><input type=text style=text-transform:uppercase name=ram id='table_size_1'></td></tr>
	<tr><th><span style='text-align:left;'>价格</span></th><td><input type=text name=price id='table_size_1'></td></tr>
	<tr><th><span style='text-align:left;'>购买时间</span></th><td><input type=text name=purtime id='table_size_1' placeholder='  DD/MM/YYYY'></td></tr>
	<tr><th><span style='text-align:left;'>资产编号</span></th><td><input type=text name=assnum id='table_size_1'></td></tr>
        <tr><th><span style='text-align:left;'>财务部设备编号</span></th><td><input type=text name=asiano id='table_size_1'></td></tr>
	<tr><th><span style='text-align:left;'>当前价值</span></th><td><input type=text name=curvalue id='table_size_1'></td></tr>
	<tr><th><span style='text-align:left;'>到期报废时间</span></th><td><input type=text name=retire id='table_size_1'></td></tr>
	<tr><th><span style='text-align:left;'>备注</span></th><td><input type=text name=other id='table_size_1'></td></tr>
        <tr><th><span style='text-align:left;'>是否审核</span></th><td><input type=radio name=checked value=是 >是 <input type=radio name=checked value=否 checked/>否</td></tr>
       









<tr><tr></tr>
<tr></tr>
<tr></tr>
<tr></tr>
<th></th><th>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<span style='text-align:left;'><input type=submit name=submit value=创建></span><input type=submit name=Submit onclick=javascript:history.back(-1); value=返回></th>
<th></th></tr></table></center>



</from>";

?>
</body>
</html>