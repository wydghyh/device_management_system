﻿<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>

<meta name="viewport" content="width=device-width,initial-scale=1,maximum-scale=1,user-scalable=no">
<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
<meta name="D_Info" content="true">
<title>D_Info</title>
<link rel="stylesheet" type="text/css" href="CSS/css_style.css"/>
<style>
tr:nth-child(even){
	background-color: #F0F8FF;
}
th{
	text-align:left;
}
table{
	width:90%;
}
/* Tabled Portrait */
@media screen and (max-width: 800px) {
    #Info{ width:80%;
	border-radius: 10px;
	border:#999 solid 3px;
	overflow:auto;
	margin-top:30px;
	padding:8px 0 8x 0;
	margin-left:9%;
	line-height:120%;}
       
	   #state { width:80%;
	float:left;
margin-left:8%;
	border-radius: 10px;
	border:#999 solid 3px;
	
	 word-break: break-all;
	padding:5px;
	line-height:120%;}
	
	#record { width:80%;
	float:left;
	height:120px;
margin-left:8%;
	border-radius: 10px;
	border:#999 solid 3px;
	overflow:auto;
	padding:5px;
	line-height:120%;}
}

</style>
</head>
<body>
<div id="Info">

<?php
session_cache_limiter('private, must-revalidate');
session_start();
$role=$_SESSION["role"];

$did = $_POST['did'];


if ($did=='') {
  $did = $_GET['did'];
}








require('DB_Info.php');


// Check connection
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}


$sql = "SELECT * FROM device inner join catalog WHERE device.cid=catalog.cid and device.did='$did'";
$result = mysqli_query($conn, $sql);
$List="<center><b>设备资料</b><p><p><p><p><p><table style='text-align:left;color:#585858;word-break: break-all;'>";

if (mysqli_num_rows($result) > 0) {
	while($row = mysqli_fetch_assoc($result)) {

		$state=$row["dstate"];
		
		$List.="
		<tr><th>Device No</th><td><span style='color:".black.";font-weight:".bold.";'>".$row["did"]."</span></td></tr>
                <tr><th>Account Number</th><td><span style='color:".black.";font-weight:".bold.";'>".$row["asiano"]."</span></td></tr>
		<tr><th>Category</th><td><span style='color:".black.";font-weight:".bold.";'>".$row["cname"]."</span></td></tr>
		<tr><th>Brand</th><td><span style='color:".black.";font-weight:".bold.";'>".$row["brand"]."</span></td></tr>
                <tr><th>Series</th><td><span style='color:".black.";font-weight:".bold.";'>".$row["series"]."</span></td></tr>
		<tr><th>Model</th><td><span style='color:".black.";font-weight:".bold.";'>".$row["model"]."</span></td></tr>
		<tr><th>Series Number</th><td><span style='color:".black.";font-weight:".bold.";'>".$row["sn"]."</span></td></tr>
		<tr><th>Ethernet address</th><td><span style='color:".black.";font-weight:".bold.";'>".$row["mac"]."</span></td></tr>
                <tr><th>Wlan address</th><td><span style='color:".black.";font-weight:".bold.";'>".$row["netmac"]."</span></td></tr>
		<tr><th>RAM</th><td><span style='color:".black.";font-weight:".bold.";'>".$row["ram"]."</span></td></tr>
		<tr><th>Company</th><td><span style='color:".black.";font-weight:".bold.";'>".$row["company"]."</span></td></tr>
		<tr><th>Location</th><td><span style='color:".black.";font-weight:".bold.";'>".$row["location"]."</span></td></tr>
		<tr><th>Asset Number</th><td><span style='color:".black.";font-weight:".bold.";'>".$row["assnum"]."</span></td></tr>
		<tr><th>Purchasing Price</th><td><span style='color:".black.";font-weight:".bold.";'>".$row["price"]."</span></td></tr>
		<tr><th>Purchasing Date</th><td><span style='color:".black.";font-weight:".bold.";'>".$row["purtime"]."</span></td></tr>
		<tr><th>Current Value</th><td><span style='color:".black.";font-weight:".bold.";'>".$row["curvalue"]."</span></td></tr>
		<tr><th>Date of retirement</th><td><span style='color:".black.";font-weight:".bold.";'>".$row["retire"]."</span></td></tr>
		<tr><th>Remark</th><td><span style='color:".black.";font-weight:".bold.";'>".$row["other"]."</span></td></tr>
                <tr><th>Whether it's checked?</th><td><span style='color:".black.";font-weight:".bold.";'>".$row["checked"]."</span></td></tr>
		";
		$List.="</table></center><p>";
		echo"<br>";
		echo"<br>";
if($role=="管理員"){
		$List.="<center><table id='table_size_1'><tr>
			<tr></tr>
			<tr></tr>
			<tr></tr>
		<th><form action=D_Edit.php method=POST><input type=hidden name=did value=".$row["did"]."><input type=submit name=Edit data-group='readonly' value=修改></form></th>
		<th><form action=D_Delete.php method=POST><input type=hidden name=did value=".$row["did"]."><input type=submit name=Delete value=删除></form></th>
                <th><input type=submit name=Submit onclick=javascript:history.back(-1); value=返回></th>
		</tr></table></center>";
		}
}
} else {
    echo "系统出现故障 !!";
}

echo $List;		
?>
</div>
<!------------------------------------------^Device_Info^------------------------------------------>

<div id="state">
<?php

$sid = $_POST['sid'];
if($role=="管理員"){
	$statebox="<form action=State_Edit.php method=post><label for combobox>设备状态更改 : </label><select name=combobox><option value='$state'>$state</option><option value='闲置'>闲置</option><option value='使用中'>使用中</option><option value='报废'>报废</option><option value='损坏'>损坏</option><input type=submit value=确定><input type=hidden name=did value=$did></form>";
}else{
	$statebox = "设备状态 : ".$state;
}

if($state=="使用中"){
	$sql="SELECT * FROM record inner join staff inner join department WHERE record.sid=staff.sid and staff.dpid=department.dpid and record.did='$did' and record.rtime is null";
	$result = mysqli_query($conn, $sql);
	$staff_list="<br /><center><table style='text-align:left;color:#585858;'>";

	if (mysqli_num_rows($result) > 0) {
		while($row = mysqli_fetch_assoc($result)) {
			$staff_list.="
			<tr></tr>
			<tr><th>员工编号</th><td><span style='color:".black.";font-weight:".bold.";'>".$row["sno"]."</span></td></tr>
			<tr><th>员工名称</th><td><span style='color:".black.";font-weight:".bold.";'>".$row["fname"]." ".$row["lname"]." ".$row["sname"]."</span></td</tr>
			<tr><th>公司</th><td><span style='color:".black.";font-weight:".bold.";'>".$row["company"]."</span></td></tr>
			<tr><th>部门</th><td><span style='color:".black.";font-weight:".bold.";'>".$row["dpname"]."</span></td></tr>
                        <tr><th>员工状态</th><td><span style='color:".black.";font-weight:".bold.";'>".$row["sstate"]."</span></td></tr>
			<tr><th>公司电话	</th><td><span style='color:".black.";font-weight:".bold.";'>".$row["ctel"]."</span></td></tr>
			<tr><th>手提电话	</th><td><span style='color:".black.";font-weight:".bold.";'>".$row["ptel"]."</span></td></tr>
			<tr><th>E-mail</th><td><span style='color:".black.";font-weight:".bold.";'>".$row["email"]."</span></td></tr>
			";
		}
		echo $statebox."<br />".$staff_list."</table></center>";
	}
}else{
	echo $statebox;
}
?>
</div>
<!------------------------------------------^Device_State^------------------------------------------>
<div id="record">
<?php

$sql="select * from record inner join staff where record.sid=staff.sid and record.did='$did'";
$result= mysqli_query($conn,$sql);
$List="<center><table style='text-align:left;color:#585858;'><tr><th>员工编号</th><th>姓名</th><th>借出时间</th><th>归还时间</th></tr>";

if (mysqli_num_rows($result) > 0) {
    // output data of each row
    while($row = mysqli_fetch_assoc($result)) {
        $List.="<tr><td><span style='color:".black.";font-weight:".bold.";'>".$row["sno"]."</span></td><td><span style='color:".black.";font-weight:".bold.";'>".$row["fname"]." ".$row["lname"]." ".$row["sname"]."</span></td><td><span style='color:".black.";font-weight:".bold.";'>".$row["ltime"]."</span></td><td><span style='color:".black.";font-weight:".bold.";'>".$row["rtime"]."</span></td></tr>";
    }
	
	$List.="</table></center>";
	echo $List;
	
} else {
    echo "设备无历史记录";
}

mysqli_close($conn);
?>
</div>

<!------------------------------------------^Record^------------------------------------------>

</body>
</html>