﻿<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Device List</title>
<style>

tr{
	height:30px;
	font-size:18px;
}

tr:nth-child(even){
	background-color: #f2f2f2;
}

tr:hover{
	background-color:#CCC;
}

input[type=submit]{
	border:none;
	background-color: transparent;
	font-size:16px;
	color:#900;
}

</style>

</head>

<body>

<a href="U_add.php"><button class="set_btn"><b>增加用户</b></button></a>

<?php

require('DB_Info.php');

if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

$sql = "SELECT * FROM user ORDER BY uid ASC";
$result = mysqli_query($conn, $sql);
$List="<table style=width:100%;>"."<tr><th>Username</th><th>修改密码</th><th>修改角色</th><th colspan='2'>修改</th></tr>";

if (mysqli_num_rows($result) > 0) {
    // output data of each row
    while($row = mysqli_fetch_assoc($result)) {
		//Click On List
        $List.="<tr><th>".$row["uname"]."</th>
		<th><form action=U_Update.php method='POST'><input type='password' name='pwd' value='".$row["pwd"]."'></th>
		<th><select name=role><option vale='".$row["role"]."'>".$row["role"]."</option><option vale='管理員'>管理員</option><option vale='一般用戶'>一般用戶</option><option vale='员工管理者'>员工管理者</option></select></th>
		<th><input type=submit name=Edit value=确定><input type=hidden name=uid value='".$row["uid"]."'></form></th>
		<th><form action=U_Delete.php method='POST'><input type=submit name=Delete value=删除><input type=hidden name=uid value='".$row["uid"]."'></form></th></tr>";
    }
} else {
    echo "No Record";
}

$List.="</table>";
echo $List;

mysqli_close($conn);
?>
</body>
</html>