﻿<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>S_Info</title>
<style>

*{
	font-size:15px;
}

select{
    width:250px;

}
input[type=text] {
    width:250px;
    box-sizing: border-box;
    border: 2px solid #ccc;
    border-radius: 4px;
    background-color: white;
    background-position: 10px 10px; 
    background-repeat: no-repeat;
}
input[type=submit]{
	border:2px solid #999;
	background-color:#FFF;
	border-radius:5px;
	margin-left:10px;
}

input[type=submit]:hover{
	background-color:#3399CC;
	color:#FFF;
}
table{border-radius: 20px;
	border:#999 solid 3px;
	padding:50px 50px 50px 50px;
	margin-top:50px;
}
</style>
</head>

<body>
<?PHP
$sid = $_POST['sid'];

require('DB_Info.php');


if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

$sql = "SELECT * FROM department";
$result = mysqli_query($conn, $sql);
$department_combo="";

if (mysqli_num_rows($result) > 0) {
    while($row = mysqli_fetch_assoc($result)) {
        $department_combo.="<option value=".$row["dpid"].">". $row["dpname"] . "</option>";
    }
} else {
    echo "Error";
}

$company_combo="<option value='HONG KONG'>HONG KONG</option><option value='ASIA'>ASIA</option>";
$sstate_combo="<option value='在职'>在职</option><option value='离职'>离职</option>";


$sql = "SELECT * FROM staff inner join department WHERE staff.dpid=department.dpid and staff.sid=".$sid;
$result = mysqli_query($conn, $sql);
$List="<center><form action=S_Update.php method=POST><table style='text-align:left;'>";

	if (mysqli_num_rows($result) > 0) {
		while($row = mysqli_fetch_assoc($result)) {
			$List.="
                        <tr><th>员工编号</th><td><input type=text name=sno value='".$row["sno"]."'></td></tr>
			<tr><th>First Name</th><td><input type=text name=fname style='text-transform:capitalize' value='".$row["fname"]."'></td></tr>
                        <tr><th>Last Name</th><td><input type=text name=lname style='text-transform:capitalize' value='".$row["lname"]."'></td></tr>

                        <tr><th>中文名</th><td><input type=text name=sname style='text-transform:capitalize' value='".$row["sname"]."'></td></tr>
			<tr><th>公司</th><td><select name=company><option value='".$row["company"]."'>". $row["company"] . "</option>".$company_combo."</td></tr>
			<tr><th>部门</th><td><select name=department><option value='".$row["dpid"]."'>". $row["dpname"] . "</option>".$department_combo."</td></tr>
			<tr><th>职位</th><td><input type=text name=position style='text-transform:capitalize' value='".$row["position"]."'></td></tr>
			<tr><th>公司电话</th><td><input type=text name=ctel value='".$row["ctel"]."'></td></tr>
			<tr><th>手提电话</th><td><input type=text name=ptel value='".$row["ptel"]."'></td></tr>
			<tr><th>E-mail</th><td><input type=text name=email value='".$row["email"]."'></td></tr>
			<tr><th>状态</th><td><select name=sstate><option value='".$row["sstate"]."'>". $row["sstate"] . "</option>".$sstate_combo."</td></tr>
			";
			$List.="
			<tr><td></td></tr>
	<tr><td></td></tr>
	<tr><td></td></tr>
	<tr><td></td></tr>
	<tr><td></td></tr>
	<tr><td></td></tr>
	<tr><td></td></tr>
	<tr><td></td></tr>
	<tr><td></td></tr>
		<tr><th></th><th>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
<input type=hidden name=sid value='$sid'><input type=submit name=submit value=提交>
<th><input type=submit name=Submit onclick=javascript:history.back(-1); value=返回></th>

</th></tr>
		</table></center>";
	}
	echo $List;

} else {
    echo "系統出現故障 !!";
}

?>

</body>
</html>