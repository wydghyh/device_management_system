﻿<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Untitled Document</title>
<link rel="stylesheet" type="text/css" href="CSS/css_style.css"/>
</head>

<body>

<form action="S_List_2.php" method="post" target="SFrame">
<label for="sno"><b>员工号：</b></label>
<input type="text" name="sno" id="ds_page" value="" placeholder=" 请输入员工号">

<form action="S_List_2.php" method="post" target="SFrame">
<label for="sno"><b>英文姓名：</b></label>
<input type="text" name="fname" id="ds_page" value="" placeholder=" 请输入英文姓名">

<form action="S_List_2.php" method="post" target="SFrame">
<label for="sno"><b>中文姓名：</b></label>
<input type="text" name="sname" id="ds_page" value="" placeholder=" 请输入中文姓名">

<?php

require('DB_Info.php');

// Check connection
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

$sql = "SELECT * FROM department order by dpname";
$result = mysqli_query($conn, $sql);
$Combo="<label for=catalog><b>部门：</b></label><select name=department id=ds_page><option value=all selected>全部</option>";

if (mysqli_num_rows($result) > 0) {
    // output data of each row
    while($row = mysqli_fetch_assoc($result)) {
        $Combo.="<option value=".$row["dpid"].">". $row["dpname"] . "</option>";
    }
} else {
    echo "Error";
}
echo $Combo."</select>";

mysqli_close($conn);
?>
<label for="company"><b>所属公司：</b></label>
<select name="company" id="ds_page">
	<option value="all"selected>全部</option>
	<option value="HONG KONG">HONG KONG</option>
	<option value="ASIA">ASIA</option>
</select>
<label for="state"><b>状态：</b></label>
<select name="sstate" id="ds_page">
	<option value="all"selected>全部</option>
	<option value="在职">在职</option>
	<option value="离职">离职</option>
</select>
&nbsp;
<input type="submit" value=" 搜寻 ">
&nbsp;&nbsp;
<input type="submit" onclick="action='S_Add.php',target='C_Frame'"  value=" 新建员工 ">
</form>

<br />
<iframe src="S_List.php" name="SFrame" width="100%" height="740px"  style="border:none;"></iframe>

</body>
</html>