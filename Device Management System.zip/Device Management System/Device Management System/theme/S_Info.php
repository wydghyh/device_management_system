﻿<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>S_Info</title>
<link rel="stylesheet" type="text/css" href="CSS/css_style.css"/>
<style>

tr:nth-child(even){
	background-color: #F0F8FF;
}

th{
	text-align:left;
}
#Staff{
	position:relative;
margin-left:27%;
	width:45%;
	height:350px;
	border-radius: 10px;
	border:#999 solid 3px;
	overflow:auto;
	margin-top:70px;
	padding:50px 10px 10px 0;
	line-height:120%;

}
table{
	width:85%;
}
</style>
</head>

<body>
<div id="Staff">
<?PHP
session_start();
$role=$_SESSION["role"];

$sid = $_POST['sid'];

require('DB_Info.php');


// Check connection
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}


$sql = "SELECT * FROM staff inner join department WHERE staff.dpid=department.dpid and staff.sid=".$sid;
$result = mysqli_query($conn, $sql);
$List="<center><b>員工资料</b><p><p><table style='text-align:left;color:#585858;'>";

	if (mysqli_num_rows($result) > 0) {
		while($row = mysqli_fetch_assoc($result)) {
			$List.="
			<tr><th>員工編號</th><td><span style='color:".black.";font-weight:".bold.";'>".$row["sno"]."</span></td></tr>
			<tr><th>員工名稱</th><td><span style='color:".black.";font-weight:".bold.";'>".$row["sname"]."</span></td></tr>
			<tr><th>公司</th><td><span style='color:".black.";font-weight:".bold.";'>".$row["company"]."</span></td></tr>
			<tr><th>部門</th><td><span style='color:".black.";font-weight:".bold.";'>".$row["dpname"]."</span></td></tr>
			<tr><th>職位</th><td><span style='color:".black.";font-weight:".bold.";'>".$row["position"]."</span></td></tr>
			<tr><th>公司電話</th><td><span style='color:".black.";font-weight:".bold.";'>".$row["ctel"]."</span></td></tr>
			<tr><th>手提電話</th><td><span style='color:".black.";font-weight:".bold.";'>".$row["ptel"]."</span></td></tr>
			<tr><th>E-mail</th><td><span style='color:".black.";font-weight:".bold.";'>".$row["email"]."</span></td></tr>
			<tr><th>狀態</th><td><span style='color:".black.";font-weight:".bold.";'>".$row["sstate"]."</span></td></tr>
			</table></center>
			";
			if($role=="管理員"||"员工管理者"){
			$List.="<br /><center><table id='table_size_1'><tr></tr>
			<tr></tr>
			<tr></tr>
			<tr></tr>
			<tr>
			<th><form action=S_Edit.php method=POST><input type=hidden name=sid value=".$row["sid"]."><input type=submit name=Edit value=Edit></form></th>
			<th><form action=S_Delete.php method=POST><input type=hidden name=sid value=".$row["sid"]."><input type=submit name=Delete value=Delete></form></th>
			<th><input type=submit name=Submit onclick=javascript:history.back(-1); value=Back></th>
			</tr></table></center>";
			}
	}
	echo $List;

} else {
    echo "系統出現故障 !!";
}

?>
</div>





<div id="Staff">
<?php
session_start();


$sid = $_POST['sid'];


require('DB_Info.php');


// Check connection
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

$sql="select * from ( select did, max(rid) maxrid, sid from record group by did order by did ) r left outer join staff s on s.sid = r.sid right outer join device d on r.did = d.did where r.sid=".$sid;
$result= mysqli_query($conn,$sql);
$List="<center><table style='text-align:left;color:#585858;'><tr><th>该员工所借设备资料</th></tr>";

if (mysqli_num_rows($result) > 0) {
    // output data of each row
    while($row = mysqli_fetch_assoc($result)) {
        $List.="<tr><td><span style='color:".black.";font-weight:".bold.";'>".$row["brand"]."</span></td><td><span style='color:".black.";font-weight:".bold.";'>
".$row["series"]."</span></td><td><span style='color:".black.";font-weight:".bold.";'>".$row["model"]."</span></td><td><span style='color:".black.";
font-weight:".bold.";'>".$row["sn"]."</span></td><td><span style='color:".black.";font-weight:".bold.";'>".$row["company"]."</span></td></tr>";
    }
	
	$List.="</table></center>";
	echo $List;
	
} else {
    echo "该员工无借阅记录";
}

mysqli_close($conn);
?>
</div>





</body>
</html>