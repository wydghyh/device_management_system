﻿<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<link rel="stylesheet" href="main.css">
<title>Untitled Document</title>
</head>

<body>
<?php
echo "update page";
$did = $_POST['did'];
$asiano = $_POST['asiano'];
$cid = $_POST['cid'];
$brand = $_POST['brand'];
$series= $_POST['series'];
$model = $_POST['model'];
$sn = $_POST['sn'];
$mac = $_POST['mac'];
$netmac = $_POST['netmac'];
$ram = $_POST['ram'];
$company = $_POST['company'];
$location = $_POST['location'];
$price = $_POST['price'];
$purtime = $_POST['purtime'];
$curvalue = $_POST['curvalue'];
$assnum = $_POST['assnum'];
$retire = $_POST['retire'];
$other = $_POST['other'];
$checked = $_POST['checked'];

require('DB_Info.php');

if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

$sql="UPDATE device SET cid ='$cid',asiano ='$asiano',brand ='$brand',series='$series',model ='$model',sn ='$sn',mac ='$mac',netmac ='$netmac', ram ='$ram',company ='$company',location ='$location', price ='$price', purtime ='$purtime', curvalue ='$curvalue', assnum ='$assnum', retire ='$retire', other ='$other', checked ='$checked' WHERE did ='$did'";

if (mysqli_query($conn, $sql)) {
    echo "<script>{alert('设备资料己更新了');location.href='D_Info.php?did=$did'}</script>";
} else {
	echo "<script>{alert('更新錯誤');location.href='D_Page.php'}</script>";
}
?>

</body>
</html>