﻿<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Untitled Document</title>
</head>

<body>
<?php

$cid=$_POST["cid"];
$asiano=$_POST["asiano"];
$brand=$_POST["brand"];
$series=$_POST["series"];
$model=$_POST["model"];
$sn=$_POST["sn"];
$mac=$_POST["mac"];
$netmac=$_POST["netmac"];
$ram=$_POST["ram"];
$company=$_POST["company"];
$location=$_POST["location"];
$price=$_POST["price"];
$purtime=$_POST["purtime"];
$curvalue = $_POST['curvalue'];
$assnum = $_POST['assnum'];
$retire = $_POST['retire'];
$other=$_POST["other"];
$checked=$_POST["checked"];

require('DB_Info.php');

if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

$sql = "SELECT * FROM device where did='$did' or sn='$sn'";
$result = mysqli_query($conn, $sql);

if (mysqli_num_rows($result) > 0) {
	 echo "<script>{alert('設備名稱相同');location.href='D_Add.php'}</script>";
}else{
	$sql="INSERT INTO device (cid,asiano,brand,series,model,sn,mac,netmac,ram,company,location,price,purtime,dstate,curvalue,assnum,retire,other,checked) VALUES ('$cid','$asiano','$brand','$series','$model','$sn','$mac','$netmac','$ram','$company','$location','$price','$purtime','闲置','$curvalue','$assnum','$retire','$other','$checked')";
	if (mysqli_query($conn, $sql)) {
 	   echo "<script>{alert('設備成功增建了');location.href='D_Page.php'}</script>";
	} else {
		echo "<script>{alert('設備尚未增建');location.href='D_Add.php'}</script>";
	}
}

?>
</body>
</html>